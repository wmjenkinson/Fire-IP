/*
 * udp_protocol.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_UDP_PROTOCOL_H_
#define ETHERNET_UDP_PROTOCOL_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"

struct SOCKET_IGNORE{

	unsigned short ident;
	unsigned short offset;
	unsigned short terminate;

	struct SOCKET_IGNORE * next;
	struct SOCKET_IGNORE * prev;
};



struct SOCKET_MANAGER{

	int nr;
	struct SOCKET_IGNORE * start;
}ignore_management;



struct UDP_SOCKET{

	unsigned char

		dmac[MACLEN],			/* Destination MAC address			*/
		dest_ip[4];

	unsigned short

		srce_port,
		dest_port;

	unsigned char

		* data;


		struct ipc_mailbox_object * udp_socket;

		struct UDP_SOCKET * next;
		struct UDP_SOCKET * prev;
	};

struct SOCKET_CTRL{

	int nr;
	struct UDP_SOCKET * sockets;
} socket_ctrl;


extern void send_udp_request(char *, int);

extern struct UDP_SOCKET * create_socket(unsigned char *, unsigned short, unsigned short);
extern void delete_socket(struct UDP_SOCKET *);


extern void * udp_get_data_socket(struct UDP_SOCKET *, int);
extern bool socket_post(unsigned short, unsigned short, unsigned char *);


extern bool port_open(unsigned short, unsigned short, unsigned char *);
extern bool terminate_ignore(unsigned short, struct IP_HEADER *);


extern void remove_socket_ignore(unsigned short ident);
extern void add_socket_ignore(unsigned short ident);
extern bool socket_ignore(unsigned short);

extern unsigned short udp_checksum(struct IP_HEADER *, int);



#endif /* ETHERNET_UDP_PROTOCOL_H_ */

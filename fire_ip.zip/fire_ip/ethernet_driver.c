
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>


#include "board_eth.h"
#include "network/ethd.h"
#include "network/gmacd.h"
#include "network/emacd.h"
#include "network/phy.h"




#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\port\task.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\semaphore_library.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\mailbox_library.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\arp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"


#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\icmp_protocol.h"
/*
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\udp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\tcp\tcp_sockets.h"
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\tcp\tcp tx.h"
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\ethernet\tcp\tcp_statemachine.h"
*/

struct task_ctrl_obj * timeouts;

char _mac_addr[6];

/* The IP and Ethernet addresses are read from the header files. */
//unsigned char hwaddr[ 6 ] = { ETHERNET_CONF_ETHADDR0,ETHERNET_CONF_ETHADDR1,ETHERNET_CONF_ETHADDR2,ETHERNET_CONF_ETHADDR3,ETHERNET_CONF_ETHADDR4,ETHERNET_CONF_ETHADDR5 };
/**
 * \brief Checksum routine for Internet Protocol family headers
 *
 * \param  addr   address of data to compute checksum
 * \param  len    length of data to compute checksum
 *
 * \return unsigned short checksum computed
 */
unsigned short in_cksum(unsigned short *addr, int len)
{
int nleft, sum;
unsigned short *w;
union {
  unsigned short us;
  unsigned char  uc[2];
} last;

unsigned short answer;

  nleft = len;
  sum = 0;
  w = addr;

  /*
   * Algorithm is simple, using a 32 bit task_accumulator (sum) :
   * add sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */
  while (nleft > 1)
  {
    sum += *w++;
    nleft -= 2;
  }

  // mop up an odd byte, if necessary
  if (nleft == 1)
  {
    last.uc[0] = *(unsigned char *)w;
    last.uc[1] = 0;
    sum += last.us;
  }

  // add back carry outs from top 16 bits to low 16 bits
  sum = (sum >> 16) + (sum & 0xffff);     // add hi 16 to low 16
  sum += (sum >> 16);                     // add carry
  answer = ~sum;                          // truncate to 16 bits
  return(answer);
}


struct ipc_mailbox_object * ethernet_mailbox;

static void build_repository(void){


	seqnum = 0xf0;

	ip_addr[0] = 192;
	ip_addr[1] = 168;
	ip_addr[2] = 1;
	ip_addr[3] = 3;


	t_ip_addr[0] = 192;
	t_ip_addr[1] = 168;
	t_ip_addr[2] = 1;
	t_ip_addr[3] = 128;

	gateway_addr[0]	= 192;
	gateway_addr[1]	= 168;
	gateway_addr[2]	= 1;
	gateway_addr[3]	= 128;

/*
	t_mac_addr[0] = 0x2c;
	t_mac_addr[1] = 0x6e;
	t_mac_addr[2] = 0x85;
	t_mac_addr[3] = 0x59;
	t_mac_addr[4] = 0x25;
	t_mac_addr[5] = 0x3b;
*/
	t_mac_addr[0] = 0x84;
	t_mac_addr[1] = 0x7b;
	t_mac_addr[2] = 0xeb;
	t_mac_addr[3] = 0x29;
	t_mac_addr[4] = 0x74;
	t_mac_addr[5] = 0x34;



	protocol_type_arp[0] = 0x08;;
	protocol_type_arp[1] = 0x06;


	protocol_type_ip4[0] = 0x08;
	protocol_type_ip4[1] = 0x00;


	ether_broacast[0] = 0xff;
	ether_broacast[1] = 0xff;
	ether_broacast[2] = 0xff;
	ether_broacast[3] = 0xff;
	ether_broacast[4] = 0xff;
	ether_broacast[5] = 0xff;


	arp_broacast[0] = 0x00;
	arp_broacast[1] = 0x00;
	arp_broacast[2] = 0x00;
	arp_broacast[3] = 0x00;
	arp_broacast[4] = 0x00;
	arp_broacast[5] = 0x00;

	hdr_ethernet[0]	= 0x00;
	hdr_ethernet[1]	= 0x01;


	ethernet_length[0] = 0x06;
	ip_length[0] = 0x04;

	arp_request[0]  = 0x00;
	arp_request[1]  = 0x01;


	arp_response[0]	= 0x00;
	arp_response[1]	= 0x02;



	vhl[0] = 0x45;
	ip_service[0] = 0x00;

	length[0]	= 0x00;
	length[1]	= 0x3c;

	ident[0]	= 0x23;
	ident[1]	= 0x66;

	frags[0]	= 0x00;
	frags[1]	= 0x00;

	ttl[0]		= 0x80;
	pcol[0]		= 0x01;

	type[0]		= 0x08; // Ping Request
	icmp_code[0]= 0x00; // Ping Request

	indent[0]	= 0x00; // Ping Request
	indent[1]	= 0x01; // Ping Request

	dns_addr[0] = 192;
	dns_addr[0] = 168;
	dns_addr[0] = 1;
	dns_addr[0] = 254;
}



struct identifier * ethernet_id;

/*
 * darkness os telegram rx'ed bridge
 */
static void ethernet_bridge (void){

	// notify the Ethernet driver that a packet has been rx'ed
	if(ethernet_driver != NULL)
		api_post_semaphore(ethernet_driver);
}

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\udp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\dns_server.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\dhcp_server.h"


static void test (void){

	unsigned char ip[4] = {192,168,1,254};

	create_socket(ip, 68, 67);

	do{

		api_delay_task(api_ownID(), kernel_tick * 5);
		send_dns_query((char *)"bbc.co.uk");

	}while("true");
}



/*
 * Ethernet hardware handler for data has been rx'ed, used to notify the ethernet
 * driver has received a packet
 */
static void ethernet_driver_rx_hardware (void){ api_invoke(ethernet_id, 0);
}

unsigned char ethernet_cache[100][1536];
void EthernetRXDriver(void){

	ethernet_id = register_deferal(ethernet_bridge);

	build_repository();
	ethernet_driver = api_create_semaphore(0, 0);


	ethernet_mailbox = api_create_mailbox();
	api_program(parse_ethernet, "Ethernet Processor", NULL, 40000, 10, 33);
	api_program(test, "test", NULL, 4000, 10, 33);


	ethd_get_mac_addr(board_get_eth(0), 0, mac_addr);
	ethd_set_rx_callback(board_get_eth(0), 0, (ethd_callback_t)&ethernet_driver_rx_hardware);


	unsigned char ip[4] = {255,255,255,255};
	create_socket(ip, 68, 67);

	dhcp_discovery();


	send_arp_request(); // Ask the Network for ARP's



	uint8_t buffer = 0;

	while (true){

		// wait for a rx Ethernet frame
		api_pend_semaphore(ethernet_driver, 0);

		uint32_t _length = 0;

		// get Ethernet telegram
		while (ethd_poll(board_get_eth(0), 0, (uint8_t*)&ethernet_cache[buffer][0], 1518, &_length) == 0) {

			if (_length > 0) {

				// send telegram to rx task for processing
				api_post_to_mailbox(ethernet_mailbox, (struct task_ctrl_obj *)35, &ethernet_cache[buffer][0]);

				// move buffer for the next telegram
				if(++buffer == 100)
					buffer = 0;
			}
		}
	}
}


/*!
 * \brief callback to manage packets reception
 * \param pkt packet to manage
 */
void parse_ethernet(void){

	unsigned char * buffer;

	struct ETHERNET_HEADER * ethernet_header;
	struct IP_HEADER * ip_header;


	while(true ){

		buffer = api_recieve_mail(ethernet_mailbox, (struct task_ctrl_obj *)36, 0);


		ethernet_header = (struct ETHERNET_HEADER *)buffer;
		ip_header = (struct IP_HEADER *)&ethernet_header->frame;

		// if it is a ARP frame, answer it
		if ((ethernet_header->ptype[0] == 0x08) && (ethernet_header->ptype[1] == 0x06)){
			handle_arp(ethernet_header);
		}

		// Internet Control Message Protocol ICMP protocol
		else if (ip_header->pcol[0] == ICMP)
		{
			// if it is our IP address
			if (!memcmp(ip_header->dip, ip_addr, 4))
			{
				// print_dbg("PING Request received...\r\n");
				 ip_protocol_handler(ethernet_header);
			}
		}

		// UDP protocol
		else if (ip_header->pcol[0] == UDP)
		{
			if (!memcmp(ip_header->dip, ip_addr, 4))
			{
				ip_protocol_handler(ethernet_header);
			}
		}

		// TCP protocol
		else if (ip_header->pcol[0] == TCP)
		{
			if (!memcmp(ip_header->dip, ip_addr, 4))
			{
				ip_protocol_handler(ethernet_header);
			}
		}
		else
		{
			if (!memcmp(ip_header->dip, ip_addr, 4))
			{
				ip_protocol_handler(ethernet_header);
			}
		}
	}
}


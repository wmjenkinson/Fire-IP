/*
 * ethernet_driver.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_ETHERNET_DRIVER_H_
#define ETHERNET_ETHERNET_DRIVER_H_

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\semaphore_library.h"

struct ipc_semaphore_object * ethernet_driver;

extern unsigned short in_cksum(unsigned short *addr, int len);

extern void EthernetRXDriver(void);


extern void parse_ethernet(void);



#endif /* ETHERNET_ETHERNET_DRIVER_H_ */

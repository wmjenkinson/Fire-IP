/*
 * dhcp_server.h
 *
 *  Created on: 6 Nov 2018
 *      Author: wmjen
 */

#ifndef FIRE_IP_DHCP_SERVER_H_
#define FIRE_IP_DHCP_SERVER_H_

extern void dhcp_discovery (void);



struct dhcp_discovery_header{

	unsigned char

		op_code,
		hw_type,
		hw_length,
		hops;

	long trnsaction_id;

	unsigned short

		seconds,
		braodcast_flag;

	unsigned char

		client_ip_addr[4],
		my_ip_addr[4],
		servere_ip_addr[4],
		gateway_ip_addr[4],

		client_hardware_addr[16],
		server_name[64],
		filename[128],

		vendor[64];
};


struct dhcp_offer_header{

	unsigned char

		op_code,
		hw_type,
		hw_length,
		hops;

	int trnsaction_id;

	unsigned short

		seconds,
		braodcasst_flag;

	unsigned char

		client_ip_addr[4],
		my_ip_addr[4],
		servere_ip_addr[4],
		gateway_ip_addr[4],

		client_hardware_addr[16],
		server_name[64],
		filename[128];

	int dhcp_message_type;
	int subnet_mask;
	int router_ip;
	int domin_nam_server;
	int ip_lease_time;
	int dhcp_server_identifier;
};


struct dhcp_request_header{

	unsigned char

		op_code,
		hw_type,
		hw_length,
		hops;

	int trnsaction_id;

	unsigned short

		seconds,
		braodcasst_flag;

	unsigned char

		client_ip_addr[4],
		my_ip_addr[4],
		servere_ip_addr[4],
		gateway_ip_addr[4],

		client_hardware_addr[16],
		server_name[64],
		filename[128];

	int dhcp_message_type;
	int clien_identifier;
	int request_ip_addr;
	int dhcp_server_identifier;
	int parameter_request_list;
};


struct dhcp_ack_header{

	unsigned char

		op_code,
		hw_type,
		hw_length,
		hops;

	int trnsaction_id;

	unsigned short

		seconds,
		braodcasst_flag;

	unsigned char

		client_ip_addr[4],
		my_ip_addr[4],
		servere_ip_addr[4],
		gateway_ip_addr[4],

		client_hardware_addr[16],
		server_name[64],
		filename[128];

	int dhcp_message_type;
	int subnet_mask;
	int router_ip;
	int domin_name_server;
	int ip_addr_lease_time;
	int dhcp_server_identifier;
};



#define Pad 						0
#define Subnet_Mask 				1
#define Time_Offset					2
#define Router						3
#define Time_Server					4
#define Name_Server					5
#define Domain_Name_Server			6
#define Log_Server					7
#define Cookie_Server				8
#define LPR_Server					9
#define Impress_Server				10
#define Resource_Location_Server	11
#define Host_Name					12
#define Boot_File_Size				13
#define Merit_Dump_File				14
#define Domain_Name					15
#define Swap_Server					16
#define Root_Path					17
#define Extension_Path				18
#define End							255


#define Requested_IP_Addr			50
#define IP_Addr_Lease_Time			51
#define Option_Overload				52
#define DHCP_Message_Type			53
#define Server_Identifier			54
#define Parameter_Request_List		55
#define Message						56
#define Max_DHCP_Message_Size		57
#define Renewal_T1					58
#define Renewal_T2					59
#define Vendor_Class_Identifier		60
#define Client_Identifier			61
#define TFTP_Server_Name			62
#define Bootfile _Name				63


#define DHCP_Discover				1
#define DHCP_Offer					2
#define DHCP_Request				3
#define DHCP_Decline				4
#define DHCP_Ack					5
#define DHCP_Nack					6
#define DHCCP_Release				7



#define Requested_IP_address 50


#endif /* FIRE_IP_DHCP_SERVER_H_ */

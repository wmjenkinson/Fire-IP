
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include "string.h"


#include <D:\atmel-software-package-master\target\common\board_eth.h>
#include <D:\atmel-software-package-master\drivers\network\phy.h>
#include <D:\atmel-software-package-master\drivers\network\ethd.h>


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\icmp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\arp_protocol.h"



void add_icmp_node(struct ICMP_IDENT * _ident){

	if( icmp_manager.nr++ == 0){
		icmp_manager.ip_first_ping_request	= _ident;
		_ident->next						= _ident;
		_ident->prev						= _ident;
	}
	else{
		_ident->next = icmp_manager.ip_first_ping_request;
		_ident->prev = icmp_manager.ip_first_ping_request->prev;

		icmp_manager.ip_first_ping_request->prev->next = _ident;
		icmp_manager.ip_first_ping_request->prev = _ident;
	}
}


void remove_icmp_node(struct ICMP_IDENT * _ident){


	if( icmp_manager.nr == 1){
		icmp_manager.nr = 0;
	}
	else
	{
		icmp_manager.nr--;
		if(icmp_manager.ip_first_ping_request == _ident){
			icmp_manager.ip_first_ping_request = _ident->next;
		}
		_ident->prev->next = _ident->next;
		_ident->next->prev = _ident->prev;
	}
}

void icmp_timeout(void){

	struct ICMP_IDENT * _ident = icmp_manager.ip_first_ping_request;

	for(int i = 0; i < icmp_manager.nr; i++){

		if(_ident->timeout + kernel_tick < kernel_core.kernel_stamp){

			* _ident->status = 9;
			remove_icmp_node(_ident); free(_ident); return;
		}
		_ident = _ident->next;
	}
}


void _handle_ping_response(struct IP_HEADER * ip_header){

	struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;
	struct ICMP_IDENT * _ident = icmp_manager.ip_first_ping_request;

	for(int i = 0; i < icmp_manager.nr; i++){

		if(memcmp(_ident->icmp_sequence, icmp_header->seq, 2) == false){

			if(icmp_header->type[0] == ICMP_REP){

				unsigned short _length = ip_header->length[0] << 8; _length |= ip_header->length[1];
				_length -= 20;

				icmp_header->check[0] = 0;
				icmp_header->check[1] = 0;

				icmp_header->type[0] = ICMP_REQ;

				unsigned short rx_check_sum = in_cksum((unsigned short *)icmp_header, _length);
				unsigned short tx_check_sum = _ident->check_sum[0] << 8; tx_check_sum |= _ident->check_sum[1];

				if(rx_check_sum == tx_check_sum){
					printf("\n\rPing received...");
					* _ident->status = 7;
				}

				else{
					printf("checksum error...");
					 * _ident->status = 8;
				}
			}

			else if(icmp_header->type[0] == ICMP_UNREACH){

				* _ident->status = icmp_header->code[0];

				// debug ping response from target ip address
				switch(icmp_header->code[0]){

					case 0:	printf("\n\rDestination network unreachable...");
					break;

					case 1:	printf("\n\rDestination host unreachable...");
					break;

					case 2:	printf("\n\rDestination protocol unreachable ...");
					break;

					case 3:	printf("\n\rDestination port unreachable...");
					break;

					case 4:	printf("\n\ruFragmentation required, and DF flag set...");
					break;

					case 5:	printf("\n\ruSource route failed...");
					break;

					case 6:	printf("\n\rDestination network unknown..");
					break;

					case 7:	printf("\n\rDestination host unknown..");
					break;

					case 8:	printf("\n\rSource host isolated..");
					break;

					case 9:	printf("\n\rNetwork administratively prohibited..");
					break;

					case 10:printf("\n\rHost administratively prohibited..");
					break;

					case 11:printf("\n\rNetwork unreachable for ToS..");
					break;

					case 12:printf("\n\rHost unreachable for ToS..");
					break;

					case 13:printf("\n\rCommunication administratively prohibited..");
					break;

					case 14:printf("\n\rHost Precedence Violation..");
					break;

					case 15:printf("\n\rPrecedence cutoff in effect ..");
					break;
				}
			}
			remove_icmp_node(_ident); free(_ident); return;
		}
		_ident = _ident->next;
	}
}

void log_ping_request(struct ICMP_HEADER * icmp_header, unsigned char * status){

	struct ICMP_IDENT * _ident = (struct ICMP_IDENT *)malloc(sizeof(struct ICMP_HEADER));

	memcpy(_ident->icmp_sequence, icmp_header->seq, 2);
	memcpy(_ident->check_sum, icmp_header->check, 2);

	_ident->status = status;
	_ident->timeout = kernel_core.kernel_stamp;

	add_icmp_node(_ident);
}


void respond_to_ping(struct ETHERNET_HEADER * ethernet_header){

	printf("\n\rPing..");

	memmove(ethernet_header->dest, ethernet_header->srce, 6);
	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct ICMP_HEADER * icmp_header =  (struct ICMP_HEADER *)&ip_header->data;

	// swap sender & receiver IP address
	memmove(ip_header->dip, ip_header->sip, 4);
	memcpy(ip_header->sip, ip_addr, 4);

	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	int chksum = in_cksum((unsigned short *)&ip_header, 20);

	// set IP checksum
	ip_header->check[0] = chksum;
	ip_header->check[1] = chksum >> 8;

	// set reply bit
	icmp_header->type[0] = 0;	// Echo
	icmp_header->code[0] = 0;	// Echo

	// reset checksum before computation
	icmp_header->check[0] = 0;
	icmp_header->check[1] = 0;

	int _length = ip_header->length[0] << 8; _length |= ip_header->length[1]; _length -= 20;

	// compute ICMP checksum
	unsigned short test_sum = in_cksum((unsigned short *)&ip_header->data, _length);

	// set ICMP checksum
	icmp_header->check[0] = test_sum;
	icmp_header->check[1] = test_sum >> 8;



	ip_layer(ethernet_header);
	free(ethernet_header);
}



void send_ping_request(unsigned char * status, int _length, unsigned char ip[4]){



	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(_length + 42);

	// My MAC address, configured during initialisation
	memcpy(ethernet_header->srce, mac_addr, 6);

	// Complete MAC Address for Target from the ARP list
	memcpy(ethernet_header->dest, t_mac_addr, 6);//retrieve_mac(&ip[0]), 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = _length + 20 + 8;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	memcpy(ip_header->pcol, pcol, 1);

	memcpy(ip_header->sip, ip_addr, 4);
	memcpy(ip_header->dip, ip, 4);

	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;

	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, 20);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;



	struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;
	icmp_header->type[0] = 8;

	memcpy(icmp_header->code, icmp_code, 1);
	memcpy(icmp_header->indent, indent, 2);

	icmp_header->seq[0] = seqnum >> 8;
	icmp_header->seq[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;

	unsigned char * ptr_icmp = &icmp_header->data;

	for(int i = 0; i < _length; i++){
		* ptr_icmp = i; ptr_icmp++;
	}

	// reset checksum before computation
	icmp_header->check[0] = 0;
	icmp_header->check[1] = 0;

	// compute ICMP checksum
	chksum = in_cksum((unsigned short *)icmp_header, (8 + _length));

	// set ICMP checksum
	icmp_header->check[0] = chksum;
	icmp_header->check[1] = chksum >> 8;


	log_ping_request(icmp_header, status);
	ip_layer(ethernet_header);

	free(ethernet_header);
}





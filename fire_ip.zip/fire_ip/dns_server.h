/*
 * dns server.h
 *
 *  Created on: 4 Nov 2018
 *      Author: wmjen
 */

#ifndef FIRE_IP_DNS_SERVER_H_
#define FIRE_IP_DNS_SERVER_H_



/****** ARP (Address Resolution Protocol) packet ******/
struct DNS_HEADER{
	unsigned char

		identification[2],				/* Hardware type					*/
	    flags[2],				/* protocol type					*/

		nr_questions[2],				/* Length of Hardware address (6)	*/
		nr_answers[2],

		authority_nr[2],
		additional_nr[2],

		question;
};

extern void send_dns_query(char * );
extern void parse_dns_reply(void);

#endif /* FIRE_IP_DNS_SERVER_H_ */

#include <stddef.h>
#include "stdbool.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>




#include <D:\atmel-software-package-master\target\common\board_eth.h>
#include <D:\atmel-software-package-master\drivers\network\phy.h>
#include <D:\atmel-software-package-master\drivers\network\ethd.h>



#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\arp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"


static bool ip_found(unsigned char * ip){

	struct ARP_NODE * node = arp_manager.arp_node;

	for(int i = 0; i < arp_manager.nr; i++){

		if(memcmp(node->ip, ip, 4) == false)
			return true;

		node = node->next;
	}
	return false;
}

unsigned char * retrieve_mac(unsigned char * ip){

	struct ARP_NODE * node = arp_manager.arp_node;

	for(int i = 0; i < arp_manager.nr; i++){

		if(memcmp(node->ip, ip, 4) == false){
			return((unsigned char *)&node->mac[0]); }

		node = node->next;
	}
	return NULL;
}

static void add_arp_node(struct ARP_NODE * node){

	if( arp_manager.nr == 0){
		arp_manager.arp_node	= node;
		node->next				= node;
		node->prev				= node;
	}
	else{
		node->next = arp_manager.arp_node;
		node->prev = arp_manager.arp_node->prev;
		arp_manager.arp_node->prev->next = node;
		arp_manager.arp_node->prev = node;
	} arp_manager.nr++;
}


bool log_arp_(struct ARP_HEADER * arp_header_){

	if(ip_found(arp_header_->sip) == false)
	{

		struct ARP_NODE * node = malloc(sizeof(struct ARP_NODE));

		memcpy(node->mac, arp_header_->smac, 6);
		memcpy(node->ip, arp_header_->sip, 4);

		add_arp_node(node);

		return true;
	}
	return false;
}


void handle_arp(struct ETHERNET_HEADER * ethernet_header){

	struct ARP_HEADER * arp_header_;

	arp_header_ = (struct ARP_HEADER *)&ethernet_header->frame;


	// Reply only if the ARP request is destined to our IP address.
	if((memcmp(arp_header_->dip, ip_addr, 4) == false) || (memcmp(arp_header_->dip, gateway_addr, 4) == false))
	{

		log_arp_(arp_header_);

		// send response, nothing else to send
		if(arp_header_->op[1] == 0x01){

			// swap sender & receiver address
			memmove(ethernet_header->dest, ethernet_header->srce, 6);
			memcpy(ethernet_header->srce, mac_addr, 6);

			// ARP Response
			arp_header_->op[1] = arp_response[1];

			// swap sender & receiver parameters
			memcpy(arp_header_->dmac, arp_header_->smac, 6);
			memmove(arp_header_->dip, arp_header_->sip, 4);

			memcpy(arp_header_->smac, mac_addr, 6);
			memcpy(arp_header_->sip, ip_addr, 4);

			ethd_send(board_get_eth(0), 0, ethernet_header, 42, NULL);
		}
	}
}


void send_arp_request(void){

	unsigned char arp_frame[42];
	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)&arp_frame;

	struct ARP_HEADER * arp_header;

	// address resolution protocol broadcast, fill in Ethernet Header
	memcpy(ethernet_header->dest, ether_broacast, 6);		// 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
	memcpy(ethernet_header->srce, mac_addr, 6);				// local mac address
	memcpy(ethernet_header->ptype, protocol_type_arp, 2);	// arp Request, 0x08, 0x06

	// address resolution protocol broadcast, fill in arp frame
	arp_header = (struct ARP_HEADER *)&ethernet_header->frame;{

		memcpy(arp_header->hdr, hdr_ethernet, 2);			// 0x00, 0x01
		memcpy(arp_header->pro, protocol_type_ip4, 2);		// 0x08, 0x00

		memcpy(arp_header->hin, ethernet_length, 1);		// 0x06
		memcpy(arp_header->pin, ip_length, 1);				// 0x04

		memcpy(arp_header->op, arp_request, 2);				// 0x01

		memcpy(arp_header->smac, mac_addr, 6);				// local mac address, responses to this address
		memcpy(arp_header->sip,  ip_addr, 4);				// local ip address, responses to this address

		memcpy(arp_header->dmac, arp_broacast, 6);			// 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		memcpy(arp_header->dip,  gateway_addr, 4);			// 255:255:255:0
	}

	ethd_send(board_get_eth(0), 0, ethernet_header, 42, NULL);
}

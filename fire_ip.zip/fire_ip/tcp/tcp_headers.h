
#ifndef ETHERNET_TCP_TCP_HEADERS_H_
#define ETHERNET_TCP_TCP_HEADERS_H_


struct TCP_SOCKET{

	unsigned char

	dmac[6],			/* Destination MAC address			*/
	dest_ip[4];

	unsigned short

	srce_port,
	dest_port;

	unsigned long tx_sequence_nr, tx_acknowledge_nr;
	unsigned long rx_sequence_nr, rx_acknowledge_nr;

	unsigned char * data;

	struct PACKET * packet_start;
	int packet_nr;

	struct WAITING_ACK * wait_ack;
	unsigned int wait_nr;

	struct ipc_mailbox_object * tcp_socket;

	struct TCP_SOCKET * next;
	struct TCP_SOCKET * prev;
};

struct TCP_SOCKET_CTRL{

	int nr;
	struct TCP_SOCKET * sockets;
} tcp_socket_ctrl;

struct PACKET{

	unsigned long long timeout;
	unsigned int expected_ack;

	unsigned int retries;

	unsigned int retrial_sequence;
	unsigned int retrial_acknowledge;

	unsigned short length;
	unsigned char flags;
	struct TCP_SOCKET * socket;

	struct PACKET * next;
	struct PACKET * prev;
};

struct WAITING_ACK{

	struct ETHERNET_HEADER * telegram;
	unsigned long long int timeout;

	struct WAITING_ACK * next;
	struct WAITING_ACK * prev;
};




#endif /* ETHERNET_TCP_TCP_HEADERS_H_ */

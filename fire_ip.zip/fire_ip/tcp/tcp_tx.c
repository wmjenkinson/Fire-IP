#include <stddef.h>
#include <string.h>


#include <D:\atmel-software-package-master\drivers\network\phy.h>
#include <D:\atmel-software-package-master\drivers\network\ethd.h>


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_checksum.h"

void send_tcp_request(int, char, struct TCP_SOCKET *);
void send_tcp_retries(int, char, struct TCP_SOCKET *, unsigned int, unsigned int);
void send_tcp_initialise(int, char);


void send_tcp_initialise(int _length, char flags){


	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(_length + ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE);

	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->dest, t_mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = IP_HEADER_SIZE + TCP_HEADER_SIZE + _length;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	ip_header->pcol[0] = TCP;

	memcpy(ip_header->sip, ip_addr, 4);
	memcpy(ip_header->dip, t_ip_addr, 4);

	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;

	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, IP_HEADER_SIZE);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;

	/*************************************************************************************/


	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;


	tcp_header->srce_port = 66;
	tcp_header->dest_port = 80;



	tcp_header->header = 20 << 2;
	tcp_header->flags = flags;

	tcp_header->window = 0;
	tcp_header->urgent = 0;

	tcp_header->checksum = tcp_checksum(ethernet_header, _length);


	//ethd_send(board_get_eth(0), 0, ethernet_header, ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE + _length, NULL);
	free(ethernet_header);
}

void send_tcp_request(int _length, char flags, struct TCP_SOCKET * socket){



	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(_length + ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE);

	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->dest, t_mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = IP_HEADER_SIZE + TCP_HEADER_SIZE + _length;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	ip_header->pcol[0] = TCP;

	memcpy(ip_header->sip, ip_addr, 4);
	memcpy(ip_header->dip, t_ip_addr, 4);

	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;

	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, IP_HEADER_SIZE);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;

	/*************************************************************************************/


	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	unsigned char * ptr = (unsigned char *)&tcp_header->urgent; ptr += 2;
	for(int i = 0; i < _length;  i++){
		*ptr = i; ptr++;
	}

	tcp_header->srce_port = socket->srce_port;
	tcp_header->dest_port = socket->dest_port;

	unsigned int seq = socket->tx_sequence_nr; socket->tx_sequence_nr += _length;
	tcp_header->seq[3] = seq;
	tcp_header->seq[2] = seq >> 8;
	tcp_header->seq[1] = seq >> 16;
	tcp_header->seq[0] = seq >> 24;

	unsigned int ack = socket->tx_acknowledge_nr;

	tcp_header->ack_[3] = ack;
	tcp_header->ack_[2] = ack >> 8;
	tcp_header->ack_[1] = ack >> 16;
	tcp_header->ack_[0] = ack >> 24;

	tcp_header->header = 20 << 2;
	tcp_header->flags = flags;

	tcp_header->window = 16616;
	tcp_header->urgent = 0;


	tcp_header->checksum = tcp_checksum(ethernet_header, _length);

	ip_layer(ethernet_header);
	free(ethernet_header);
}


void send_tcp_retries(int _length, char flags, struct TCP_SOCKET * socket, unsigned int retry_sequence, unsigned int retry_acknowledge){



	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(_length + ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE);

	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->dest, t_mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = IP_HEADER_SIZE + TCP_HEADER_SIZE + _length;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	ip_header->pcol[0] = TCP;

	memcpy(ip_header->sip, ip_addr, 4);
	memcpy(ip_header->dip, t_ip_addr, 4);



	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;

	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, IP_HEADER_SIZE);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;

	/*************************************************************************************/


	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	unsigned char * ptr = (unsigned char *)&tcp_header->urgent; ptr += 2;
	for(int i = 0; i < _length;  i++){
		*ptr = i; ptr++;
	}

	tcp_header->srce_port = socket->srce_port;
	tcp_header->dest_port = socket->dest_port;

	unsigned int seq = retry_sequence;
	tcp_header->seq[3] = seq;
	tcp_header->seq[2] = seq >> 8;
	tcp_header->seq[1] = seq >> 16;
	tcp_header->seq[0] = seq >> 24;

	unsigned int ack = retry_acknowledge;
	tcp_header->ack_[3] = ack;
	tcp_header->ack_[2] = ack >> 8;
	tcp_header->ack_[1] = ack >> 16;
	tcp_header->ack_[0] = ack >> 24;

	tcp_header->header = 20 << 2;
	tcp_header->flags = flags;

	tcp_header->window = 16616;
	tcp_header->urgent = 0;


	tcp_header->checksum = tcp_checksum(ethernet_header, _length);

	ip_layer(ethernet_header);
	free(ethernet_header);
}







#ifndef ETHERNET_TCP_TCP_RX_H_
#define ETHERNET_TCP_TCP_RX_H_

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"

extern unsigned int get_acknowledge(struct TCP_HEADER *);
extern unsigned int get_sequence(struct TCP_HEADER *);
extern void handle_reception(struct ETHERNET_HEADER * ip_header, struct TCP_HEADER *);
extern void scan_rx_fragmentation(void);


#endif /* ETHERNET_TCP_TCP_RX_H_ */

/*
 * tcp_ack_system.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_IP_LAYER_TCP_TCP_ACK_SYSTEM_H_
#define ETHERNET_IP_LAYER_TCP_TCP_ACK_SYSTEM_H_




#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"

//extern void handle_ack(struct TCP_HEADER *);
extern void remove_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet);
extern void add_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet);


#endif /* ETHERNET_IP_LAYER_TCP_TCP_ACK_SYSTEM_H_ */

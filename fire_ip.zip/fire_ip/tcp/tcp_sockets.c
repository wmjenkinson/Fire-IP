#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\mailbox_library.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_ack_system.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_sockets.h"

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_rx.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_tx.h"

struct TCP_SOCKET * tcp_create_socket(unsigned char *, unsigned short, unsigned short);

//struct TCP_SOCKET * tcp_get_socket(struct TCP_HEADER * tcp_header);

void tcp_send(unsigned short, unsigned char, struct TCP_SOCKET *);
//bool tcp_socket_post(unsigned short, unsigned short, unsigned char *);
//bool tcp_port_open(unsigned short, unsigned short, unsigned char *);
void open_socket(struct TCP_SOCKET * );



static void tcp_add_socket_node(struct TCP_SOCKET * socket){

	if( tcp_socket_ctrl.nr++ == 0){
		tcp_socket_ctrl.sockets		= socket;
		socket->next				= socket;
		socket->prev				= socket;
	}
	else{
		socket->next = tcp_socket_ctrl.sockets;
		socket->prev = tcp_socket_ctrl.sockets->prev;

		tcp_socket_ctrl.sockets->prev->next = socket;
		tcp_socket_ctrl.sockets->prev = socket;
	}
}

/*
static void tcp_remove_socket_node(struct TCP_SOCKET * socket){


	if( tcp_socket_ctrl.nr == 1){
		tcp_socket_ctrl.nr = 0;
	}
	else
	{
		tcp_socket_ctrl.nr--;
		if(tcp_socket_ctrl.sockets == socket){
			tcp_socket_ctrl.sockets = socket->next;
		}
		socket->prev->next = socket->next;
		socket->next->prev = socket->prev;
	}
}
*/

void open_socket(struct TCP_SOCKET * socket){


	send_tcp_initialise(0, SYN);

	struct ETHERNET_HEADER * ethernet_header;

	while((ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 10000)) == (void *)3){
		send_tcp_initialise(0, SYN);
	}

	//Obtain the relative sequence and acknowledge numbers
	struct IP_HEADER  * ip_header  = (struct IP_HEADER *)&ethernet_header->frame;
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	unsigned int tcp_seq = tcp_header->seq[0] << 24;
	tcp_seq |= tcp_header->seq[1] << 16;
	tcp_seq |= tcp_header->seq[2] << 8;
	tcp_seq |= tcp_header->seq[3];

	unsigned int tcp_ack = tcp_header->ack_[0] << 24;
	tcp_ack |= tcp_header->ack_[1] << 16;
	tcp_ack |= tcp_header->ack_[2] << 8;
	tcp_ack |= tcp_header->ack_[3];

	socket->tx_sequence_nr = tcp_ack++;
	socket->tx_acknowledge_nr = ++tcp_seq;

	send_tcp_request(0, ACK, socket);
}

struct TCP_SOCKET * tcp_get_socket(struct TCP_HEADER * tcp_header){

	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;

	unsigned short dport = tcp_header->dest_port;
	unsigned short sport = tcp_header->srce_port;


	for(int i =0; i < tcp_socket_ctrl.nr; i++){

		if((socket->srce_port == dport) && (socket->dest_port == sport)){
			return socket;
		}
		socket = socket->next;
	}
	return NULL;
}

struct TCP_SOCKET * tcp_create_socket(unsigned char * ip_address, unsigned short srce_port, unsigned short dest_port){

	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;

	for(int i =0; i < tcp_socket_ctrl.nr; i++){

		if((socket->srce_port == srce_port) && (socket->dest_port == dest_port)){
			return socket;
		}
		socket = socket->next;
	}

	socket = malloc(sizeof(struct TCP_SOCKET));

	socket->dest_port = dest_port;
	socket->srce_port = srce_port;

	socket->tcp_socket = api_create_mailbox();

	tcp_add_socket_node(socket);
	return socket;
}

void * tcp_get_data_socket(struct TCP_SOCKET * socket, int timeout){
	return((void *)api_recieve_mail(socket->tcp_socket, from_anyone, timeout));
}

void tcp_send(unsigned short _length, unsigned char flags, struct TCP_SOCKET * socket){

	struct PACKET * packet = malloc(sizeof(struct PACKET));

	packet->expected_ack = socket->tx_sequence_nr + _length;

	packet->retrial_sequence = socket->tx_sequence_nr;
	packet->retrial_acknowledge = socket->tx_acknowledge_nr;

	packet->length = _length;
	packet->socket = socket;
	packet->timeout = kernel_core.kernel_stamp;
	packet->retries = 0;
	packet->flags   = flags;

	add_ack_packet(socket, packet);
	send_tcp_request(_length, flags, socket);
}


bool tcp_socket_post(unsigned short dport, unsigned short sport, unsigned char * data){

	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;

	for(int i = 0; i < tcp_socket_ctrl.nr; i++){

		if((socket->srce_port == dport)){// && (socket->dest_port == sport)){
			api_post_to_mailbox(socket->tcp_socket, to_anyone, data); return true;
		}
		socket = socket->next;
	}
	return false;
}

bool tcp_port_open(unsigned short dport, unsigned short sport, unsigned char * ip_srce){

	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;

	for(int i = 0; i < tcp_socket_ctrl.nr; i++){

		if(socket->srce_port == dport){
			return true;
		}
		socket = socket->next;
	}
	return false;
}



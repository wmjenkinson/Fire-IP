#include "string.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"


unsigned short tcp_checksum(struct ETHERNET_HEADER *, int);
unsigned short tcp_checksum(struct ETHERNET_HEADER * ethernet_headaer, int _length){

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_headaer->frame;
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	struct TCP_PSEUDO * pseudo_header = malloc(sizeof(struct TCP_PSEUDO));

	memcpy(pseudo_header->srce_ip, ip_addr, 4);
	memcpy(pseudo_header->dest_ip, t_ip_addr, 4);

	pseudo_header->zero = 0;
	pseudo_header->pcol = TCP;
	pseudo_header->tcp_length = (tcp_header->header >> 2) + _length;

	unsigned short pseudo_chksum = in_cksum((unsigned short *)pseudo_header, sizeof(struct TCP_PSEUDO));
	pseudo_chksum = ~pseudo_chksum;

	unsigned short temp_checksum = tcp_header->checksum;

	tcp_header->checksum = pseudo_chksum;
	free(pseudo_header);

	unsigned short return_checksum = in_cksum((unsigned short *)&ip_header->data, (tcp_header->header >> 2) + _length);
	tcp_header->checksum = temp_checksum;

	return return_checksum;
}





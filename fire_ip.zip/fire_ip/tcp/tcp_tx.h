/*
 * tcp_tx.h
 *
 *  Created on: 17 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_TCP_TCP_TX_H_
#define ETHERNET_TCP_TCP_TX_H_


extern void send_tcp_request(int, char, struct TCP_SOCKET *);
extern void send_tcp_retries(int, char, struct TCP_SOCKET *, unsigned int, unsigned int);
extern void send_tcp_initialise(int, char);



#endif /* ETHERNET_TCP_TCP_TX_H_ */

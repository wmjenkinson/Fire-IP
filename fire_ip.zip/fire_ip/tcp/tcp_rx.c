#include "string.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"


#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_sockets.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_tx.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_rx.h"


unsigned int get_acknowledge(struct TCP_HEADER * tcp_header){

	unsigned int tcp_ack = tcp_header->ack_[0] << 24;
	tcp_ack |= tcp_header->ack_[1] << 16;
	tcp_ack |= tcp_header->ack_[2] << 8;
	tcp_ack |= tcp_header->ack_[3];

	return tcp_ack;
}


unsigned int get_sequence(struct TCP_HEADER * tcp_header){

	unsigned int tcp_seq = tcp_header->seq[0] << 24;
	tcp_seq |= tcp_header->seq[1] << 16;
	tcp_seq |= tcp_header->seq[2] << 8;
	tcp_seq |= tcp_header->seq[3];

	return tcp_seq;
}


static void waiting_acknowledge(struct TCP_SOCKET * socket, struct ETHERNET_HEADER * ethernet_header){

	struct WAITING_ACK * packet = (struct WAITING_ACK *)malloc(sizeof(struct WAITING_ACK));

	packet->telegram = ethernet_header;
	packet->timeout  = kernel_core.kernel_stamp + (kernel_tick * 2);

	if( socket->wait_nr++ == 0){
		socket->wait_ack	= packet;
		packet->next		= packet;
		packet->prev		= packet;
	}
	else{
		packet->next = socket->wait_ack;
		packet->prev = socket->wait_ack->prev;

		socket->wait_ack->prev->next = packet;
		socket->wait_ack->prev = packet;
	}
}


static void remove_from_waiting_acknowledge(struct TCP_SOCKET * socket, struct WAITING_ACK * packet){


	if( socket->wait_nr == 1){
		socket->wait_nr = 0;
	}
	else
	{
		socket->wait_nr--;
		if(socket->wait_ack == packet){
			socket->wait_ack = packet->next;
		}
		packet->prev->next = packet->next;
		packet->next->prev = packet->prev;
	}
}


void handle_reception(struct ETHERNET_HEADER * ethernet_header, struct TCP_HEADER * tcp_header){


	bool broadcast = false;

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct TCP_SOCKET * socket = tcp_get_socket(tcp_header);

	unsigned short _length = ip_header->length[0] << 8; _length += ip_header->length[1];

	unsigned int sequence_nr = get_sequence(tcp_header);

	if(sequence_nr == socket->tx_acknowledge_nr){
		socket->tx_acknowledge_nr += _length - (IP_HEADER_SIZE + (tcp_header->header >> 2)); broadcast = true;
	}
	else{
		waiting_acknowledge(socket, ethernet_header);
	}

	struct WAITING_ACK * packet = socket->wait_ack;

	for(int scan = 0; scan < socket->wait_nr; scan++){

		ethernet_header = packet->telegram;

		ip_header = (struct IP_HEADER *)&ethernet_header->frame;
		tcp_header = (struct TCP_HEADER *)&ip_header->data;

		unsigned short __length = ip_header->length[0] << 8; __length += ip_header->length[1];

		unsigned int _sequence_nr = get_sequence(tcp_header);

		if(_sequence_nr == socket->tx_acknowledge_nr){

			socket->tx_acknowledge_nr += __length - (IP_HEADER_SIZE + (tcp_header->header >> 2));
			remove_from_waiting_acknowledge(socket, packet); packet = packet->next;

			//re_scan
			scan = 0; broadcast = true;
		}
		else{
			packet = packet->next;
		}
	}
	if(broadcast)
		send_tcp_request(0, ACK, socket);
}

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_sockets.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_tx.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\mailbox_library.h"


//void close_socket(struct TCP_SOCKET *);
void tcp_server(struct TCP_SOCKET *);
void rx_close(struct TCP_SOCKET *);

static unsigned char get_flags(struct ETHERNET_HEADER * ethernet_header){

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	return(tcp_header->flags);
}

void close_socket(struct TCP_SOCKET * socket){

	struct ETHERNET_HEADER * ethernet_header;

	while(api_accept_mail(socket->tcp_socket, from_anyone) != 0){
	}
				tcp_get_data_socket(socket, 0);




	send_tcp_request(0, FIN + ACK, socket);


	ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);

	unsigned char flags = get_flags(ethernet_header);


	if(flags && ACK)
	{
		ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);

		flags = get_flags(ethernet_header);

		if((flags && FIN) && (flags && ACK))
		{
			socket->tx_sequence_nr += 1; socket->tx_acknowledge_nr += 1;
			send_tcp_request(0, ACK, socket);
		}
	}
}

void tcp_server(struct TCP_SOCKET * socket){

	struct ETHERNET_HEADER * ethernet_header;

	unsigned char flags;

	while(api_accept_mail(socket->tcp_socket, from_anyone) != 0);

	do{
		ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);
		flags = get_flags(ethernet_header);
	} while(!(flags && SYN));

	struct IP_HEADER * ip_header = (struct IP_HEADER * )&ethernet_header->frame;
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER * )&ip_header->data;

	socket->tx_sequence_nr = tcp_header->ack_[0] << 24;
	socket->tx_sequence_nr |= tcp_header->ack_[1] << 16;
	socket->tx_sequence_nr |= tcp_header->ack_[2] << 8;
	socket->tx_sequence_nr |= tcp_header->ack_[3];
	socket->tx_sequence_nr++;

	socket->tx_acknowledge_nr = tcp_header->seq[0] << 24;
	socket->tx_acknowledge_nr |= tcp_header->seq[1] << 16;
	socket->tx_acknowledge_nr |= tcp_header->seq[2] << 8;
	socket->tx_acknowledge_nr |= tcp_header->seq[3];
	socket->tx_acknowledge_nr++;

	socket->dest_port = tcp_header->srce_port;

	do{

		send_tcp_request(0, SYN + ACK, socket);

		ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);
		flags = get_flags(ethernet_header);
	} while(!(flags && ACK));


	socket->tx_sequence_nr++;
	for(int i = 0; i < 10; i++){
		//tcp_send(10, PUSH + ACK, socket); api_delay_task(api_ownID(), 10000);
	}
}

void rx_close(struct TCP_SOCKET * socket){


	struct ETHERNET_HEADER * ethernet_header;
	unsigned char flags;

	while(api_accept_mail(socket->tcp_socket, from_anyone) != 0);

	socket->tx_acknowledge_nr++;

	do{
		ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);
		flags = get_flags(ethernet_header);
	} while(!(flags && FIN));

	send_tcp_request(0, ACK, socket); api_delay_task(api_ownID(), 1000);
	send_tcp_request(0, FIN + ACK, socket);


	do{
		ethernet_header = (struct ETHERNET_HEADER *)tcp_get_data_socket(socket, 0);
		flags = get_flags(ethernet_header);
	} while(!(flags && ACK));
}



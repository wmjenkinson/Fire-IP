#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"

void handle_ack(struct TCP_HEADER *);
void remove_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet);
void add_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet);





void add_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet){

	if( socket->packet_nr++ == 0){
		socket->packet_start	= packet;
		packet->next			= packet;
		packet->prev			= packet;
	}
	else{
		packet->next = socket->packet_start;
		packet->prev = socket->packet_start->prev;

		socket->packet_start->prev->next = packet;
		socket->packet_start->prev = packet;
	}
}


void remove_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet){


	if( socket->packet_nr == 1){
		socket->packet_nr = 0;
	}
	else
	{
		socket->packet_nr--;
		if(socket->packet_start == packet){
			socket->packet_start = packet->next;
		}
		packet->prev->next = packet->next;
		packet->next->prev = packet->prev;
	}
}

void handle_ack(struct TCP_HEADER * tcp_header){

	struct TCP_SOCKET * _socket = tcp_socket_ctrl.sockets;

	unsigned short dport = tcp_header->dest_port;
	unsigned short sport = tcp_header->srce_port;

	unsigned int tcp_ack = tcp_header->ack_[0] << 24;
	tcp_ack |= tcp_header->ack_[1] << 16;
	tcp_ack |= tcp_header->ack_[2] << 8;
	tcp_ack |= tcp_header->ack_[3];

	for(int i = 0; i < tcp_socket_ctrl.nr; i++){

		if((_socket->srce_port == dport) && (_socket->dest_port == sport)){

			struct PACKET * packet = _socket->packet_start;
			struct PACKET * tmp_packet;

			for(int j = 0; j < _socket->packet_nr; j++){

				if(packet->expected_ack <= tcp_ack){
					tmp_packet = packet->next; remove_ack_packet(_socket, packet); free(packet); packet = tmp_packet; }
				else
					packet = packet->next;
			}
			return;
		}
		_socket = _socket->next;
	}
}





/*
 * ack_system.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_IP_LAYER_TCP_ACK_SYSTEM_H_
#define ETHERNET_IP_LAYER_TCP_ACK_SYSTEM_H_



extern void _handle_ack(struct TCP_HEADER *);




#endif /* ETHERNET_IP_LAYER_TCP_ACK_SYSTEM_H_ */

/*
 * tcp_checksum.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_IP_LAYER_TCP_TCP_CHECKSUM_H_
#define ETHERNET_IP_LAYER_TCP_TCP_CHECKSUM_H_



extern unsigned short tcp_checksum(struct ETHERNET_HEADER *, int);


#endif /* ETHERNET_IP_LAYER_TCP_TCP_CHECKSUM_H_ */

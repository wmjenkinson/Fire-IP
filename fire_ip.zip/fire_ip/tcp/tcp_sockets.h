#ifndef ETHERNET_TCP_TCP_SOCKETS_H_
#define ETHERNET_TCP_TCP_SOCKETS_H_


#include <stdbool.h>

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"


extern void close_socket(struct TCP_SOCKET *);
extern void scan_active_sockets(void);

extern struct TCP_SOCKET * tcp_get_socket(struct TCP_HEADER *);
extern void * tcp_get_data_socket(struct TCP_SOCKET *, int);

extern bool tcp_port_open(unsigned short, unsigned short, unsigned char *);
extern bool tcp_socket_post(unsigned short, unsigned short, unsigned char *);

#endif /* ETHERNET_TCP_TCP_SOCKETS_H_ */

/*
 * tcp_statemachine.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_TCP_TCP_STATEMACHINE_H_
#define ETHERNET_TCP_TCP_STATEMACHINE_H_

extern void tcp_server(struct TCP_SOCKET *);
extern void rx_close(struct TCP_SOCKET *);

#endif /* ETHERNET_TCP_TCP_STATEMACHINE_H_ */

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"



static void remove_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet){


	if( socket->packet_nr == 1){
		socket->packet_nr = 0;
	}
	else
	{
		socket->packet_nr--;
		if(socket->packet_start == packet){
			socket->packet_start = packet->next;
		}
		packet->prev->next = packet->next;
		packet->next->prev = packet->prev;
	}
}

void _handle_ack(struct TCP_HEADER * );
void _handle_ack(struct TCP_HEADER * tcp_header){

	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;

	unsigned short dport = tcp_header->dest_port;
	unsigned short sport = tcp_header->srce_port;

	unsigned int tcp_ack = tcp_header->ack_[0] << 24;
	tcp_ack |= tcp_header->ack_[1] << 16;
	tcp_ack |= tcp_header->ack_[2] << 8;
	tcp_ack |= tcp_header->ack_[3];

	for(int j = 0; j < tcp_socket_ctrl.nr; j++){

		if((socket->srce_port == dport) && (socket->dest_port == sport)){

			struct PACKET * packet = socket->packet_start;

			for(int i = 0; i < socket->packet_nr; i++){

				if(packet->expected_ack < tcp_ack){
					remove_ack_packet(socket, packet); packet = packet->next; }
			}
			return;
		}
		socket = socket->next;
	}
}


#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include <D:\atmel-software-package-master\target\common\board_eth.h>
#include <D:\atmel-software-package-master\drivers\network\phy.h>
#include <D:\atmel-software-package-master\drivers\network\ethd.h>

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_rx.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\icmp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\udp_protocol.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_sockets.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_checksum.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\fragmentation_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_sockets.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\ack_system.h"



void ip_layer(struct ETHERNET_HEADER * ethernet_header){

	// IP header!!!
	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;

	// TCP header!!!
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

		/*
		 * first step is to see if fragmentation should occurred or not, if not then
		 * the telegram is passed onto the hardware, it however it is to be fragmented,
		 * then it will build a header corresponding to protocol used and send it
		 * then finish sending ip packets with the remaining data in fragments
		 */

		int _length = ip_header->length[0] << 8; _length |= ip_header->length[1];

		// handle TCP protocol!!!
		if(ip_header->pcol[0] == TCP){

			_length -= (IP_HEADER_SIZE + (tcp_header->header >> 2));

			// fragment packet to be sent
			if(_length > (MAXFRAME - (ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + (tcp_header->header >> 2)))){

				int test =  (MAXFRAME - (ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + (tcp_header->header >> 2)));
				build_tcp_header(ethernet_header, test); _length -= test;
			}

			// send TCP packet - no fragmentation required
			else{
				ethd_send(board_get_eth(0), 0, ethernet_header, _length + (ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + (tcp_header->header >> 2)), NULL);
				_length = 0;
			}
		}

		// UDP or ICMP protocol, both have identital memory headaers
		else{

			_length -= (UDP_HEADER_SIZE + IP_HEADER_SIZE);

			// fragment or not!!!!!!
			if(_length > 1472){

				// build first ICMP header
				if(ip_header->pcol[0] == ICMP){
					build_icmp_header(ethernet_header, 1472); _length -= 1472; }

				// build first UDP header
				else if(ip_header->pcol[0] == UDP){
					build_udp_header(ethernet_header, 1472); _length -= 1472; }
			}
			// no IP fragmentation send send telegram
			else{
				ethd_send(board_get_eth(0), 0, ethernet_header, _length + 42, NULL);
				_length = 0;
			}
		}


	// Finish Up sending the rest of the data
	int telegram_offset = 1;
	while(_length != 0){

		 build_ip_fragment(ethernet_header, telegram_offset++, _length);

		 if(_length / 1480)
			_length -= 1480;
		 else
			_length = 0;
	}
}

/*
 * build ICMP fragment header
 */
void build_icmp_header(struct ETHERNET_HEADER * ethernet_header, int t_length){


	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct ICMP_HEADER * icmp_header =  (struct ICMP_HEADER *)&ip_header->data;

	unsigned char tx_frame[t_length + 42];
	struct ETHERNET_HEADER * temp_ethernet_header = (struct ETHERNET_HEADER *)&tx_frame[0];



	struct IP_HEADER * tmp_ip_header = (struct IP_HEADER *)&temp_ethernet_header->frame;
	struct ICMP_HEADER * tmp_icmp_header =  (struct ICMP_HEADER *)&tmp_ip_header->data;

	unsigned char * ptr_dest, * ptr_srce;

	ptr_dest = (unsigned char *)temp_ethernet_header;
	ptr_srce = (unsigned char *)ethernet_header;

	for(int i = 0; i < 42; i++){
		* ptr_dest = * ptr_srce; ptr_dest++; ptr_srce++;
	}


	int _length = t_length + 28;
	tmp_ip_header->length[0] = _length >> 8;
	tmp_ip_header->length[1] = _length;

	unsigned char *srce_data = &icmp_header->data; unsigned char *dest_data = &tmp_icmp_header->data;

	for(int i = 0; i < t_length; i++){
		* dest_data = * srce_data; srce_data++; dest_data++; }


	tmp_ip_header->frags[0] = 0x00;
	tmp_ip_header->frags[1] = 0x00;
	if(t_length ==  1472)
		tmp_ip_header->frags[0] = 0x20;



	// reset checksum before computation
	tmp_ip_header->check[0] = 0;
	tmp_ip_header->check[1] = 0;

	// compute IP checksum
	int chksum = in_cksum((unsigned short *)&tmp_ip_header, 20);

	// set IP checksum
	tmp_ip_header->check[0] = chksum >> 8;
	tmp_ip_header->check[1] = chksum;

	// send request, nothing else to send
	ethd_send(board_get_eth(0), 0, temp_ethernet_header, t_length + 42, NULL);
}

/*
 * build UDP first IP transaction
 */
void build_udp_header(struct ETHERNET_HEADER * ethernet_header, int t_length){


	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct UDP_HEADER * udp_header =  (struct UDP_HEADER *)&ip_header->data;

	unsigned char tx_frame[t_length + 42];
	struct ETHERNET_HEADER * temp_ethernet_header = (struct ETHERNET_HEADER *)&tx_frame[0];



	struct IP_HEADER * tmp_ip_header = (struct IP_HEADER *)&temp_ethernet_header->frame;
	struct UDP_HEADER * tmp_udp_header =  (struct UDP_HEADER *)&tmp_ip_header->data;

	unsigned char * ptr_dest, * ptr_srce;

	ptr_dest = (unsigned char *)temp_ethernet_header;
	ptr_srce = (unsigned char *)ethernet_header;

	for(int i = 0; i < 42; i++){
		* ptr_dest = * ptr_srce; ptr_dest++; ptr_srce++;
	}


	int _length = t_length + 28;

	tmp_ip_header->length[0] = _length >> 8;
	tmp_ip_header->length[1] = _length;

	unsigned char *srce_data = &udp_header->data; unsigned char *dest_data = &tmp_udp_header->data;

	for(int i = 0; i < t_length; i++){
		* dest_data = * srce_data; srce_data++; dest_data++; }


	tmp_ip_header->frags[0] = 0x00;
	tmp_ip_header->frags[1] = 0x00;
	if(t_length ==  1472)
		tmp_ip_header->frags[0] = 0x20;



	// reset checksum before computation
	tmp_ip_header->check[0] = 0;
	tmp_ip_header->check[1] = 0;

	// compute IP checksum
	int chksum = in_cksum((unsigned short *)&tmp_ip_header, 20);

	// set IP checksum
	tmp_ip_header->check[0] = chksum >> 8;
	tmp_ip_header->check[1] = chksum;

	// send request, nothing else to send

	ethd_send(board_get_eth(0), 0, temp_ethernet_header, t_length + 42, NULL);
}

/*
 * build TCP header IP fragmebt
 */
void build_tcp_header(struct ETHERNET_HEADER * ethernet_header, int t_length){


	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct TCP_HEADER * tcp_header =  (struct TCP_HEADER *)&ip_header->data;


	unsigned char tx_frame[1514];
	struct ETHERNET_HEADER * temp_ethernet_header = (struct ETHERNET_HEADER *)&tx_frame[0];

	struct IP_HEADER * tmp_ip_header = (struct IP_HEADER *)&temp_ethernet_header->frame;
	struct TCP_HEADER * tmp_tcp_header =  (struct TCP_HEADER *)&tmp_ip_header->data;

	unsigned char * ptr_dest, * ptr_srce;

	ptr_dest = (unsigned char *)temp_ethernet_header;
	ptr_srce = (unsigned char *)ethernet_header;

	for(int i = 0; i < (14 + 20); i++){
		* ptr_dest = * ptr_srce; ptr_dest++; ptr_srce++;
	}


	int _length = t_length + 20 + (tcp_header->header >> 2);

	tmp_ip_header->length[0] = _length >> 8;
	tmp_ip_header->length[1] = _length;

	unsigned char * srce_data = (unsigned char *)&tcp_header->urgent; srce_data += 2;
	unsigned char * dest_data = (unsigned char *)&tmp_tcp_header->urgent; dest_data += 2;

	for(int i = 0; i < t_length; i++){
		* dest_data = * srce_data; srce_data++; dest_data++; }


	tmp_ip_header->frags[0] = 0x00;
	tmp_ip_header->frags[1] = 0x00;

	if(t_length ==  (1480 - (tcp_header->header >> 2)))
		tmp_ip_header->frags[0] = 0x20;



	// reset checksum before computation
	tmp_ip_header->check[0] = 0;
	tmp_ip_header->check[1] = 0;

	// compute IP checksum
	int chksum = in_cksum((unsigned short *)&tmp_ip_header, 20);

	// set IP checksum
	tmp_ip_header->check[0] = chksum >> 8;
	tmp_ip_header->check[1] = chksum;

	tmp_tcp_header->srce_port = tcp_header->srce_port;
	tmp_tcp_header->dest_port = tcp_header->dest_port;

	memcpy(tmp_tcp_header->seq, tcp_header->seq, 4);
	memcpy(tmp_tcp_header->ack_, tcp_header->ack_, 4);

	tmp_tcp_header->flags = tcp_header->flags;
	tmp_tcp_header->header = tcp_header->header;

	tmp_tcp_header->window = tcp_header->window;
	tmp_tcp_header->urgent = 0;
	tmp_tcp_header->checksum = tcp_header->checksum;



	// send request, nothing else to send
	ethd_send(board_get_eth(0), 0, temp_ethernet_header, 1514 + 14, NULL);
}

/*
 * Build IP fragment for any IP packet that needs fragmentation
 */
void build_ip_fragment(struct ETHERNET_HEADER * ethernet_header, int telegram_offset, int _length){



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;

	unsigned char buffer[1514];

	struct ETHERNET_HEADER * temp_ethernet_header = (struct ETHERNET_HEADER *)&buffer[0];
	struct IP_HEADER * tmp_ip_header = (struct IP_HEADER *)&temp_ethernet_header->frame;

	unsigned char * ptr_dest, * ptr_srce;

	ptr_dest = (unsigned char *)temp_ethernet_header;
	ptr_srce = (unsigned char *)ethernet_header;

	for(int i = 0; i < 34; i++){
		* ptr_dest = * ptr_srce; ptr_dest++; ptr_srce++; }


	int fragment_length = 0;

		if(_length / 1480)
			fragment_length = 1480;
		else
			fragment_length = _length % 1480;

	fragment_length += 20;

	tmp_ip_header->length[0] = fragment_length >> 8;
	tmp_ip_header->length[1] = fragment_length;

	int data_offset;

	if(telegram_offset == 1)
		data_offset = 1472;
	else
		data_offset = 1472 + (1480 * (telegram_offset - 1));

	unsigned char *srce_data = &icmp_header->data;
	unsigned char *dest_data = &tmp_ip_header->data;

	srce_data += data_offset;

	for(int i = 0; i < fragment_length - 20; i++){
		* dest_data = * srce_data; dest_data++; srce_data++; }


	unsigned short ip_offset = 0xb9 * telegram_offset;
	if(_length < 1480){
		tmp_ip_header->frags[0] = ip_offset >> 8;
		tmp_ip_header->frags[1] = ip_offset;
	}
	else{
		tmp_ip_header->frags[0] = 0x20;

		tmp_ip_header->frags[0] |= ip_offset >> 8;
		tmp_ip_header->frags[1]  = ip_offset;
	}


	// reset checksum before computation
	tmp_ip_header->check[0] = 0;
	tmp_ip_header->check[1] = 0;

	// compute IP checksum
	int chksum = in_cksum((unsigned short *)&tmp_ip_header, 20);

	// set IP checksum
	tmp_ip_header->check[0] = chksum >> 8;
	tmp_ip_header->check[1] = chksum;

	// send request, nothing else to send
	ethd_send(board_get_eth(0), 0, temp_ethernet_header, fragment_length + 14, NULL);
}


/*
 * build a UDP packet from the fragments received
 */
static void build_udp_packet(	struct ETHERNET_HEADER * ethernet_header,
								struct IP_HEADER * ip_header,
								struct IP_IDENT * identifier,
								unsigned char * start, int memory_block_required){

	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;

	udp_header->sport[0] = identifier->udp_srce_port[0];
	udp_header->sport[1] = identifier->udp_srce_port[1];

	udp_header->dport[0] = identifier->udp_dest_port[0];
	udp_header->dport[1] = identifier->udp_dest_port[1];


	udp_header->length[0] = identifier->udp_length[0];
	udp_header->length[1] = identifier->udp_length[1];

	unsigned char * ptr_udp, * ptr_data;

	ptr_udp = &udp_header->data;
	ptr_data = start;


	for(int i = 0; i < memory_block_required; i++){
		* ptr_udp = * ptr_data; ptr_udp++; ptr_data++;
	}

	unsigned short checksum = identifier->udp_check[0] << 8; checksum |= identifier->udp_check[1];

	free(start);
	remove_ident_node(identifier); free(identifier);


	unsigned short computed_check = udp_checksum(ip_header, memory_block_required);

	unsigned short dport = udp_header->dport[0] << 8; dport |= udp_header->dport[1];
	unsigned short sport = udp_header->sport[0] << 8; sport |= udp_header->sport[1];


	if(checksum == computed_check)
		socket_post(dport, sport, (unsigned char *)ethernet_header);
}




/*
 * build a ICMP packet from the fragments received
 */
static void build_icmp_packet(	struct ETHERNET_HEADER * ethernet_header,
								struct IP_HEADER * ip_header,
								struct IP_IDENT * identifier,
								unsigned char * start, int memory_block_required){


	struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;

	icmp_header->indent[0] = identifier->icmp_ident[0];
	icmp_header->indent[1] = identifier->icmp_ident[1];



	icmp_header->type[0] = identifier->icmp_type[0];
	icmp_header->code[0] = 0x00;


	memcpy(icmp_header->seq, identifier->icmp_sequence, 2);
	memcpy(icmp_header->check, identifier->icmp_checksum, 2);

	unsigned char * ptr_icmp, * ptr_data;

	ptr_icmp = &icmp_header->data;
	ptr_data = start;

	// build telegram data block
	for(int i = 0; i < memory_block_required; i++){
		* ptr_icmp = * ptr_data; ptr_icmp++; ptr_data++;
	}

	free(start);
	remove_ident_node(identifier); free(identifier);

	int test = icmp_header->check[0] << 8; test |= icmp_header->check[1];

	icmp_header->check[0] = 0x00;
	icmp_header->check[1] = 0x00;

	int temp = in_cksum((unsigned short *)&ip_header->data, memory_block_required + 8);


	//if(temp == test)
	{
		icmp_header->check[0] = temp >> 8;
		icmp_header->check[1] = temp;

		if(icmp_header->type[0] == ICMP_REQ){
			respond_to_ping(ethernet_header);
		}

		else if((icmp_header->type[0] == ICMP_REP) || (icmp_header->type[0] == ICMP_UNREACH)){
			_handle_ping_response(ip_header); }
	}
}


/*
 * build a TCP packet from the fragments received
 */
static void build_tcp_packet(	struct ETHERNET_HEADER * ethernet_header,
								struct IP_HEADER * ip_header,
								struct IP_IDENT * identifier,
								unsigned char * start, int memory_block_required){


	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;


	tcp_header->srce_port = identifier->tcp_ident_header->srce_port;
	tcp_header->dest_port = identifier->tcp_ident_header->dest_port;

	memcpy(tcp_header->seq, identifier->tcp_ident_header->seq, 4);
	memcpy(tcp_header->ack_, identifier->tcp_ident_header->ack_, 4);

	tcp_header->header = identifier->tcp_ident_header->header;
	tcp_header->flags = identifier->tcp_ident_header->flags;

	unsigned char * ptr_tcp, * ptr_data;

	ptr_tcp = (unsigned char *)&tcp_header->urgent; ptr_tcp += 2;
	ptr_data = start;

	for(int i = 0; i < memory_block_required; i++){
		* ptr_tcp = * ptr_data; ptr_tcp++; ptr_data++;
	}

	free(start);
	remove_ident_node(identifier); free(identifier);
}


// begin re-construct ip packet
void build_ip_header(struct IP_IDENT * identifier){

	struct IP_FRAGMENT * fragment = identifier->start;
	int memory_block_required = 0;


	// Calculate Size of Telegram
	for(int i = 0; i <  identifier->nr; i++){


		if(fragment->sequence == 0){

			// compile ip fragment header
			if(identifier->protocol[0] == TCP){
				memory_block_required = fragment->length - ((identifier->tcp_ident_header->header >> 2) + IP_HEADER_SIZE);
			}

			// ICMP or UDP telegram to be processed
			else{
				memory_block_required = fragment->length - (8 + IP_HEADER_SIZE);
			}
		}
		else {
			// compile ip fragment
			memory_block_required += fragment->length - IP_HEADER_SIZE;
		}
		fragment = fragment->next;
	}

	// Allocate Data Packet
	identifier->datum = malloc(memory_block_required);

	unsigned char * start = identifier->datum;

	fragment = identifier->start;


	// copy data to ip packet
	for(int i = 0; i <  identifier->nr; i++){

		// schedule fragments to be processed in the proper order!!!
		while(fragment->sequence != i){
			fragment = fragment->next;
		}

		bool flags = fragment->flags;

		if(fragment->sequence == 0){ // First Packet

			if(identifier->protocol[0] == TCP){
				for(int j = 0; j < fragment->length - (IP_HEADER_SIZE + (identifier->tcp_ident_header->header >> 2)); j++){
					* identifier->datum = fragment->data[j]; identifier->datum++;
				}
			}
			else{
				for(int j = 0; j < fragment->length - (IP_HEADER_SIZE + 8); j++){
					* identifier->datum = fragment->data[j]; identifier->datum++;
				}
			}
		}
		else if(flags){ // fragments

			for(int j = 0; j < fragment->length - IP_HEADER_SIZE; j++){
				* identifier->datum = fragment->data[j]; identifier->datum++;
			}
		}
	}

	// Reset Pointer to Start of Transaction
	identifier->datum = start;

	// Delete Fragments
	int temp = identifier->nr;

	for(int k = 0; k < temp; k++){
		fragment = identifier->start; remove_ip_fragment(identifier, fragment); free(fragment);
	}

	// re-build header
	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(memory_block_required + 34 + 8);

	memcpy(ethernet_header->srce, identifier->source_mac, 6);
	memcpy(ethernet_header->dest, mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);


	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;

	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	int tmp = 0;

	if(identifier->protocol[0] == TCP)
		tmp = memory_block_required + IP_HEADER_SIZE + (identifier->tcp_ident_header->header >> 2);
	else
		tmp = memory_block_required + IP_HEADER_SIZE + UDP_HEADER_SIZE;

	ip_header->length[0] = tmp >> 8;
	ip_header->length[1] = tmp;

	memcpy(ip_header->ident, identifier->ident, 2);

	ip_header->frags[0] = 0x00;
	ip_header->frags[1] = 0x00;

	ip_header->ttl[0] = 128;
	ip_header->pcol[0] = identifier->protocol[0];

	memcpy(ip_header->sip, identifier->source_ip, 4);
	memcpy(ip_header->dip, ip_addr, 4);


	memcpy(ip_header->check, identifier->ip_checksum, 2);

	// build the respective telegram!!!
	if(identifier->protocol[0] == ICMP){
		build_icmp_packet(ethernet_header, ip_header, identifier, start, memory_block_required);
	}
	else if(identifier->protocol[0] == UDP){
		build_udp_packet(ethernet_header, ip_header, identifier, start, memory_block_required);
	}
	else if(identifier->protocol[0] == TCP){
		build_tcp_packet(ethernet_header, ip_header, identifier, start, memory_block_required);
	}
}

void compute_offset(struct IP_IDENT * _ident){

	struct IP_FRAGMENT * ip_fragment = _ident->start;

	int sum = 0;

	// calculate the total data received thus far and compare with
	// built-up value fragment, i.e. last fragment specifying the
	// total fragment(s) size
	for(int i = 0; i < (_ident->nr - 1); i++){
		sum += 0xb9; ip_fragment = ip_fragment->next;
	}

	// all the fragments have now been received, build IP telegram
	if(_ident->computed_offset == sum){
		build_ip_header(_ident);
	}
}


void build_data(bool flags, int sequence, struct IP_FRAGMENT * fragment, struct ETHERNET_HEADER * ethernet_header){

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;

	// configure telegram headers, ICMP, UDP and TCP
	struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;
	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;
	struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

	if(!flags){
		int _length = ip_header->length[0] << 8; _length |= ip_header->length[1]; _length -= 20;

		unsigned char * ptr_data = &ip_header->data;

		for(int i = 0; i < _length; i++){
			fragment->data[i] = * ptr_data; ptr_data++;
		}
	}
	else{
		if(sequence == 0){

			if(ip_header->pcol[0] == ICMP){

				unsigned char * ptr_data = &icmp_header->data;

				for(int i = 0; i < 1480 - ICMP_HEADER_SIZE; i++){
					fragment->data[i] = * ptr_data; ptr_data++;
				}
			}
			else if(ip_header->pcol[0] == UDP){

				unsigned char * ptr_data = &udp_header->data;

				for(int i = 0; i < 1480 - UDP_HEADER_SIZE; i++){
					fragment->data[i] = * ptr_data; ptr_data++;
				}
			}
			else if(ip_header->pcol[0] == TCP){

				unsigned char * ptr_data = (unsigned char *)&tcp_header->urgent; ptr_data += 2;

				for(int i = 0; i < 1480 - (tcp_header->header >> 2); i++){
					fragment->data[i] = * ptr_data; ptr_data++;
				}
			}
		}
		else{
			unsigned char * ptr_data = &ip_header->data;

			for(int i = 0; i < 1480; i++){
				fragment->data[i] = * ptr_data; ptr_data++;
			}
		}
	}
}


static bool socket_active(bool flags, int sequence, struct ETHERNET_HEADER * ethernet_header, bool found, struct IP_IDENT * identifier){

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;

	unsigned short _ident = ip_header->ident[0] << 8; _ident |= ip_header->ident[1];

	if(sequence == 0){

		struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;

		unsigned short dport = udp_header->dport[0] << 8; dport |= udp_header->dport[1];
		unsigned short sport = udp_header->sport[0] << 8; sport |= udp_header->sport[1];

		if(!port_open(dport, sport, ip_header->sip)){

			add_socket_ignore(_ident);
			if(found == true){

				struct IP_FRAGMENT * fragment;


				for(int i = 0; i < identifier->nr; i++){
					fragment = identifier->start; remove_ip_fragment(identifier, fragment); free(fragment);
				}
				remove_ident_node(identifier);
				free(identifier);
			}
			return false;
		}
	}
	else if(socket_ignore(_ident)){

		if(terminate_ignore(_ident, ip_header))
			remove_socket_ignore(_ident);

		return false;
	}
	return true;
}


/*
 * insert fragment into the system
 */
void insert_packet_fragment(bool flags, int sequence, struct ETHERNET_HEADER * ethernet_header){

	struct IP_FRAGMENT * fragment;
	struct IP_IDENT * identifier = ip_manager.ip_first_ident;

	bool found = false;

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;

	// find ident node
	for(int i = 0; i < ip_manager.nr; i++){

		if(memcmp(&identifier->ident, &ip_header->ident, 2) == 0){
			found = true; goto complete_ident_processing;
		}
		else{
			identifier = identifier->next;
		}
	}


	complete_ident_processing:


	if(ip_header->pcol[0] == UDP){
		if(!socket_active(flags, sequence, ethernet_header, found, identifier)) return;
	}

	// Node not found, create anew node
	if(found == false){
		identifier = malloc(sizeof(struct IP_IDENT)); identifier->time_rec = kernel_core.kernel_stamp;

		// configure fragment builder with the correct identifier
		memcpy(identifier->ident, ip_header->ident, 2);

		//add telegram identifier to the list to process
		add_ident_node(identifier);

	}


	// first fragment - copy telegram header detial's
	if(sequence == 0){

		memcpy(identifier->source_mac, ethernet_header->srce, 6);
		memcpy(identifier->source_ip, ip_header->sip, 4);
		memcpy(identifier->frags, ip_header->frags, 2);
		memcpy(identifier->protocol, ip_header->pcol, 1);
		memcpy(identifier->ip_checksum, ip_header->check, 2);



		if(ip_header->pcol[0] == ICMP){

			struct ICMP_HEADER * icmp_header = (struct ICMP_HEADER *)&ip_header->data;

			memcpy(identifier->icmp_type, icmp_header->type, 1);
			memcpy(identifier->icmp_sequence, icmp_header->seq, 2);
			memcpy(identifier->icmp_checksum, icmp_header->check, 2);
			memcpy(identifier->icmp_ident, icmp_header->indent, 2);
		}

		else if(ip_header->pcol[0] == UDP){
			memcpy(identifier->udp_srce_port, udp_header->sport, 2);
			memcpy(identifier->udp_dest_port, udp_header->dport, 2);

			memcpy(identifier->udp_check, udp_header->check, 2);
			memcpy(identifier->udp_length, udp_header->length, 2);
		}

		else if(ip_header->pcol[0] == TCP){

			struct TCP_HEADER * tcp_header = (struct TCP_HEADER *)&ip_header->data;

			identifier->tcp_ident_header = malloc(sizeof(struct TCP_HEADER));
			identifier->tcp_ident_header->srce_port = tcp_header->srce_port;
			identifier->tcp_ident_header->dest_port = tcp_header->dest_port;

			memcpy(identifier->tcp_ident_header->seq, tcp_header->seq, 4);
			memcpy(identifier->tcp_ident_header->ack_, tcp_header->ack_, 4);

			identifier->tcp_ident_header->header = tcp_header->header;
			identifier->tcp_ident_header->flags = tcp_header->flags;
		}
	}

	// create a ip fragment
	fragment = malloc(sizeof(struct IP_FRAGMENT)); fragment->sequence = sequence;

	fragment->offset = sequence * 0xb9;
	fragment->sequence = sequence;
	fragment->flags = flags;
	fragment->length = ip_header->length[0] << 8; fragment->length |= ip_header->length[1];



	// add fragment to system
	add_ip_fragment(identifier, fragment);
	// copy data to fragment for re-build
	build_data(flags, sequence, fragment, ethernet_header);


	// last fragment
	if(!flags){
		identifier->computed_offset = fragment->offset; }

	// test if all fragments have been received
	if(identifier->computed_offset != 0){
		compute_offset(identifier); }
}


void ip_protocol_handler(struct ETHERNET_HEADER * ethernet_header){

	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;

	bool flags = false;

	if(ip_header->frags[0] & 0x20)
		flags = true;

	int offset = (ip_header->frags[0] & 0x1f) << 8; offset |= ip_header->frags[1];

	// no fragmentation!!! handle data
	if((flags == false) && (offset == 0)){

		int _length = ip_header->length[0] << 8; _length |= ip_header->length[1];

		struct ETHERNET_HEADER * new_ethernet = malloc(_length + 14);

		unsigned char * ptr_dest = (unsigned char *)new_ethernet;
		unsigned char * ptr_srce = (unsigned char *)ethernet_header;


		for(int i = 0; i < _length + 14; i++){
			* ptr_dest = * ptr_srce; ptr_dest++; ptr_srce++;
		}

		struct IP_HEADER  * new_ip_header  = (struct IP_HEADER *) &new_ethernet->frame;


		if(new_ip_header->pcol[0] == ICMP){

			struct ICMP_HEADER * new_icmp_header = (struct ICMP_HEADER *)&new_ip_header->data;

			if(new_icmp_header->type[0] == ICMP_REQ)
				respond_to_ping(new_ethernet);

			else if((new_icmp_header->type[0] == ICMP_REP) || (new_icmp_header->type[0] == ICMP_UNREACH)){
				_handle_ping_response(new_ip_header); free(new_ethernet);
			}
		}


		else if(new_ip_header->pcol[0] == UDP){


			struct UDP_HEADER * new_udp_header = (struct UDP_HEADER *)&new_ip_header->data;

			unsigned short checksum = new_udp_header->check[0] << 8; checksum |= new_udp_header->check[1];
			int __length = new_udp_header->length[0] << 8; __length |= new_udp_header->length[1];

			unsigned short dport = new_udp_header->dport[0] << 8; dport |= new_udp_header->dport[1];
			unsigned short sport = new_udp_header->sport[0] << 8; sport |= new_udp_header->sport[1];

			if(port_open(dport, sport, new_ip_header->sip)){
				if(checksum == udp_checksum(new_ip_header, __length - 8)){
					socket_post(dport, sport, (unsigned char *)new_ethernet);
				}
			}
		}
		else if(new_ip_header->pcol[0] == TCP){

			struct TCP_HEADER * new_tcp_header = (struct TCP_HEADER *)&new_ip_header->data;

			unsigned short dport = new_tcp_header->dest_port;
			unsigned short sport = new_tcp_header->srce_port;

			if(tcp_port_open(dport, sport, new_ip_header->sip)){

				unsigned short __length = new_ip_header->length[0] << 8; __length |= new_ip_header->length[1];
				__length -= (IP_HEADER_SIZE + (new_tcp_header->header >> 2));

				if(new_tcp_header->checksum == tcp_checksum(new_ethernet, __length)){

					if(new_tcp_header->flags & ACK)
						_handle_ack(new_tcp_header);


					if(new_tcp_header->flags & PUSH)
						handle_reception(new_ethernet, new_tcp_header);

					tcp_socket_post(dport, sport, (unsigned char *)new_ethernet);
				}
			}
		}
	}
	else
		// fragment, process fragments received
		insert_packet_fragment(flags, offset / 0xb9, ethernet_header);
}



void add_ip_fragment(struct IP_IDENT * _ident, struct IP_FRAGMENT * node){

	if( _ident->nr++ == 0){
		_ident->start		= node;
		node->next			= node;
		node->prev			= node;
	}
	// Insert at the head of the Link List
	else{
		_ident->start->next->prev = node;
		node->prev = _ident->start;
		node->next = _ident->start->next;
		_ident->start->next = node;
	}
}

void remove_ip_fragment(struct IP_IDENT * _ident, struct IP_FRAGMENT * node){


	if( _ident->nr == 1){
		_ident->nr = 0;
	}
	else
	{
		_ident->nr--;
		if(_ident->start == node){
			_ident->start = node->next;
		}
		node->prev->next = node->next;
		node->next->prev = node->prev;
	}
}

void add_ident_node(struct IP_IDENT * _ident){

	if( ip_manager.nr++ == 0){
		ip_manager.ip_first_ident	= _ident;
		_ident->next				= _ident;
		_ident->prev				= _ident;
	}
	else{
		_ident->next = ip_manager.ip_first_ident;
		_ident->prev = ip_manager.ip_first_ident->prev;

		ip_manager.ip_first_ident->prev->next = _ident;
		ip_manager.ip_first_ident->prev = _ident;
	}
}


void remove_ident_node(struct IP_IDENT * _ident){


	if( ip_manager.nr == 1){
		ip_manager.nr = 0;
	}
	else
	{
		ip_manager.nr--;
		if(ip_manager.ip_first_ident == _ident){
			ip_manager.ip_first_ident = _ident->next;
		}
		_ident->prev->next = _ident->next;
		_ident->next->prev = _ident->prev;
	}
}

void handle_ip_frag_timeout(void);
void handle_ip_frag_timeout(void){

	struct IP_IDENT * _ident = ip_manager.ip_first_ident;
	struct IP_FRAGMENT * fragment;

	for(int i = 0; i < ip_manager.nr; i++){
		if((_ident->time_rec + kernel_tick * 2) < kernel_core.kernel_stamp)


		for(int j = 0; j < _ident->nr; j++){
			fragment = _ident->start; remove_ip_fragment(_ident, fragment); free(fragment);
		}
		remove_ident_node(_ident);
		free(_ident);
	}
}

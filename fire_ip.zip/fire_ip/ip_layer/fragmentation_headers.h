/*
 * fragmentation_headers.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_IP_LAYER_FRAGMENTATION_HEADERS_H_
#define ETHERNET_IP_LAYER_FRAGMENTATION_HEADERS_H_

/*
 * fragmentation_headers.h
 *
 * Created: 19/01/2018 18:04:33
 *  Author: wmjen
 */


#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>


/* Structure of one Node */
struct IP_FRAGMENT{

	struct IP_FRAGMENT * next;
	struct IP_FRAGMENT * prev;

	unsigned int sequence;

	bool flags;
	unsigned int length;

	unsigned int offset;
	unsigned char data[1480];
};




struct IP_IDENT{
	unsigned char

	size,			/* Telegram Size	*/
	ident[2],		/* Telegram Ident	*/
	frags[2],
	ip_checksum[2],

	source_mac[6],
	source_ip[4],

	protocol[1];

	int computed_offset;
	int length;

	unsigned long long time_rec;

	unsigned char

	icmp_sequence[2],
	icmp_checksum[2],
	icmp_type[1],
	icmp_ident[2],
	udp_srce_port[2],
	udp_dest_port[2],
	udp_check[2],
	udp_length[2];

	struct TCP_HEADER * tcp_ident_header;

	struct IP_FRAGMENT * start;
	int nr;

	struct IP_IDENT * next;
	struct IP_IDENT * prev;

	unsigned char * datum;
};


struct IP_MANGER{
	struct IP_IDENT * ip_first_ident;
	int nr;
} ip_manager;





#endif /* ETHERNET_IP_LAYER_FRAGMENTATION_HEADERS_H_ */

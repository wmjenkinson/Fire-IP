
#ifndef ETHERNET_IP_LAYER_IP_PROTOCOL_H_
#define ETHERNET_IP_LAYER_IP_PROTOCOL_H_

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\fragmentation_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"


extern void insert_packet_fragment(bool, int, struct ETHERNET_HEADER *);
extern void add_ident_node(struct IP_IDENT *);
extern void add_ip_fragment(struct IP_IDENT * , struct IP_FRAGMENT *);
extern void remove_ip_fragment(struct IP_IDENT * , struct IP_FRAGMENT *);
extern void ip_protocol_handler(struct ETHERNET_HEADER *);
extern void remove_ident_node(struct IP_IDENT *);
extern void compute_offset(struct IP_IDENT *);
extern void build_data(bool, int, struct IP_FRAGMENT *, struct ETHERNET_HEADER *);
extern void build_ip_header(struct IP_IDENT *);

extern void ip_layer(struct ETHERNET_HEADER *);

extern void build_icmp_header(struct ETHERNET_HEADER *, int);
extern void build_udp_header(struct ETHERNET_HEADER *, int);
extern void build_tcp_header(struct ETHERNET_HEADER *, int);
extern void build_ip_fragment(struct ETHERNET_HEADER *, int, int);



#endif /* ETHERNET_IP_LAYER_IP_PROTOCOL_H_ */

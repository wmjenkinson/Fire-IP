

#ifndef FIRE_IP_ARP_PROTOCOL_H_
#define FIRE_IP_ARP_PROTOCOL_H_

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"


/* Structure of one Node */
struct ARP_NODE{
	unsigned char

		mac[6],		/* MAC (Ethernet Address	*/
		ip[4];				/* IP Address				*/

	struct ARP_NODE * next;
	struct ARP_NODE * prev;
};

struct ARP_MANGER{
	struct ARP_NODE * arp_node;
	unsigned short nr;
} arp_manager;

extern unsigned char * retrieve_mac(unsigned char * ip);
extern bool log_arp_(struct ARP_HEADER * );
extern void handle_arp(struct ETHERNET_HEADER * );
extern void send_arp_request(void);




#endif /* FIRE_IP_ARP_PROTOCOL_H_ */

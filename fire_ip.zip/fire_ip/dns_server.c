#include "dns_server.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\udp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include <string.h>

// DNS Server address - bt.com
char dns_server[4] = {62, 6, 40, 178};

// DNS packet identifier
unsigned short dns_identificatins = 0x1725;



void send_dns_query(char * ip_name){

	int name_question = 6 + strlen(ip_name);


	struct DNS_HEADER * dns_header = (struct DNS_HEADER *)malloc((sizeof(struct DNS_HEADER) + name_question));

	// identify the dns packets
	dns_header->identification[0] = dns_identificatins >> 8;
	dns_header->identification[1] = dns_identificatins++;

	// standard query
	dns_header->flags[0] = 0x01;
	dns_header->flags[1] = 0x00;

	// number of questions, embedded so only one question
	dns_header->nr_questions[0] = 0x00;
	dns_header->nr_questions[1] = 0x01;


	// number of answers, zero for a request
	dns_header->nr_answers[0] = 0x00;
	dns_header->nr_answers[1] = 0x00;

	// all zero's in query message
	dns_header->authority_nr[0] = 0x00;
	dns_header->authority_nr[1] = 0x00;

	// all zero's in query message
	dns_header->additional_nr[0] = 0x00;
	dns_header->additional_nr[1] = 0x00;


	char * question = (char *)&dns_header->question;
	char * start = ip_name;

	int nr_chars = 0;

	// scan-line address field one
	while(* ip_name++ != '.')
		nr_chars++;

	// build question!!!
	* question++ = nr_chars; nr_chars = 0;

	ip_name = start;

	// copy name to DNS query
	while(* ip_name != '\0'){

		if(* ip_name == '.'){

			start = ip_name;

			nr_chars = 0;
			ip_name++;

			//Scan-line, remaining Internet name fields
			while(!((* ip_name == '.') || (* ip_name == '\0'))){
					nr_chars++; ip_name++; }

			* question++ = nr_chars;

			ip_name = start;
		}

		else{
			* question++ = * ip_name;
		}
		ip_name++;
	}

	* question++ = 0x00;

	// TYPE
	* question++ = 0x00;
	* question++ = 0x01;

	// CLASS
	* question++ = 0x00;
	* question++ = 0x01;

	send_udp_request((char *)dns_header->identification, sizeof(struct DNS_HEADER) + name_question);
}

void parse_dns_reply(void){

}

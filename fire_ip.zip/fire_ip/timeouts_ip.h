/*
 * timeouts_ip.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_TIMEOUTS_IP_H_
#define ETHERNET_TIMEOUTS_IP_H_



#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\fragmentation_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\tcp\tcp_headers.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"


extern void remove_ip_fragment(struct IP_IDENT * ident, struct IP_FRAGMENT * node);
extern void remove_ack_packet(struct TCP_SOCKET * socket, struct PACKET * packet);
extern void send_tcp_retries(int length, char flags, struct TCP_SOCKET * socket, unsigned int retry_sequence, unsigned int retry_acknowledge);

void ip_handle_timeouts(void);
void ip_handle_timeouts(void){

	struct IP_IDENT * ident = ip_manager.ip_first_ident;
	struct IP_FRAGMENT * fragment;

	for(int i = 0; i < ip_manager.nr; i++){
		if(ident->time_rec + kernel_tick < kernel_core.kernel_stamp){

			for(int k = 0; k <  ident->nr; k++){
				fragment = ident->start; remove_ip_fragment(ident, fragment); api_free(fragment);
			}
		}
	}


	struct TCP_SOCKET * socket = tcp_socket_ctrl.sockets;
	struct PACKET * packet;

	for(int i = 0; i < tcp_socket_ctrl.nr; i++){

		packet = socket->packet_start;
		for(int k = 0; k < socket->packet_nr; k++){

			struct PACKET * tmp_packet = packet->next;

			if(packet->retries == 4)
				remove_ack_packet(socket, packet);


			else if(packet->timeout + kernel_tick < kernel_core.kernel_stamp){
				send_tcp_retries(packet->length, packet->flags, socket, packet->retrial_sequence, packet->retrial_acknowledge);
				packet->retries++;
			}

			packet = tmp_packet;
		}
		socket = socket->next;
	}
	extern void icmp_timeout(void); icmp_timeout();
}






#endif /* ETHERNET_TIMEOUTS_IP_H_ */

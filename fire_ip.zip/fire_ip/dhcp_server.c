#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\dhcp_server.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\udp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"



unsigned int transaction_id = 0x1111;

static void build_dhcp_request (struct dhcp_discovery_header * dhcp_discovery){

	int dhcp_length = sizeof(struct dhcp_discovery_header);

	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(dhcp_length + ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + UDP_HEADER_SIZE);

	unsigned char broadcast_mac[6] = {0xff,
									  0xff,
									  0xff,
									  0xff,
									  0xff,
									  0xff};

	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->dest, broadcast_mac, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = IP_HEADER_SIZE + UDP_HEADER_SIZE + dhcp_length;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	ip_header->pcol[0] = UDP;

	unsigned char source_ip[4] = {0, 0, 0, 0};
	memcpy(ip_header->sip, source_ip, 4);


	unsigned char destinition_ip[4] = {0xff, 0xff, 0xff, 0xff};
	memcpy(ip_header->dip, destinition_ip, 4);

	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;


	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, IP_HEADER_SIZE);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;



	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;
	udp_header->sport[0] = 0;
	udp_header->sport[1] = 68;

	udp_header->dport[0] = 0;
	udp_header->dport[1] = 67;

	unsigned short t_length = UDP_HEADER_SIZE + dhcp_length;
	udp_header->length[0] = t_length >> 8;
	udp_header->length[1] = t_length;



	unsigned char * udp_data = &udp_header->data;
	unsigned char * data = (unsigned char *)&dhcp_discovery->op_code;


	for(int i = 0; i < dhcp_length;  i++){
		* udp_data = * data; udp_data++; data++;
	}

	struct PSEUDO_HEADER * pseudo_header = malloc(sizeof(struct PSEUDO_HEADER));
	memcpy(pseudo_header->scre, ip_addr, 4);
	memcpy(pseudo_header->dest, t_ip_addr, 4);

	pseudo_header->zero[0] = 0;
	pseudo_header->pcol[0] = UDP;

	unsigned short p_length = UDP_HEADER_SIZE + t_length;
	pseudo_header->udp_length[0] = p_length >> 8;
	pseudo_header->udp_length[1] = p_length;

	unsigned short pseudo_chksum = in_cksum((unsigned short *)pseudo_header, 12);
	pseudo_chksum = ~pseudo_chksum;

	udp_header->check[0] = pseudo_chksum >> 8;
	udp_header->check[1] = pseudo_chksum;

	free(pseudo_header);

	unsigned short udp_chksum = in_cksum((unsigned short *)&ip_header->data, UDP_HEADER_SIZE + dhcp_length);

	udp_header->check[0] = udp_chksum >> 8;
	udp_header->check[1] = udp_chksum;

	ip_layer(ethernet_header);
	free(ethernet_header);
}

void dhcp_discovery (void){


	// create socket

	struct dhcp_discovery_header * dhcp_discovery = (struct dhcp_discovery_header *)malloc(sizeof(struct dhcp_discovery_header));
	memset(dhcp_discovery, 0, sizeof(struct dhcp_discovery_header));

	dhcp_discovery->op_code 	= DHCP_Discover;
	dhcp_discovery->hw_type 	= 0x01;
	dhcp_discovery->hw_length 	= 0x06;
	dhcp_discovery->hops	 	= 0x00;

	dhcp_discovery->trnsaction_id = transaction_id++;

	dhcp_discovery->seconds = 0x00;
	dhcp_discovery->braodcast_flag = 0x01;

	dhcp_discovery->client_hardware_addr[0] = mac_addr[0];
	dhcp_discovery->client_hardware_addr[1] = mac_addr[1];
	dhcp_discovery->client_hardware_addr[2] = mac_addr[2];
	dhcp_discovery->client_hardware_addr[3] = mac_addr[3];
	dhcp_discovery->client_hardware_addr[4] = mac_addr[4];
	dhcp_discovery->client_hardware_addr[5] = mac_addr[5];


	build_dhcp_request(dhcp_discovery);
	free(dhcp_discovery);
}


//static void dhcp_statemachine (void){
//
//	static state = DISCOVER;
//}


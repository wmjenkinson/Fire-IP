#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include "string.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\udp_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\mailbox_library.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_driver.h"



bool socket_ignore(unsigned short ident_){

	struct SOCKET_IGNORE * socket = ignore_management.start;

	for(int i = 0; i < ignore_management.nr; i++){
		if(socket->ident == ident_)
			return true;

		socket = socket->next;
	}
	return false;
}

bool terminate_ignore(unsigned short _ident, struct IP_HEADER * ip_header){

	struct SOCKET_IGNORE * socket = ignore_management.start;

	int offset = (ip_header->frags[0] & 0x1f) << 8; offset |= ip_header->frags[1];

	bool flags = false;

	if(ip_header->frags[0] & 0x20)
		flags = true;

	for(int i = 0; i < ignore_management.nr; i++){

		if(socket->ident == _ident){
			socket->offset += 0xb9;

			if(!flags)
				socket->terminate = offset;

			if(socket->terminate == socket->offset)
				return true;
		}
		socket = socket->next;
	}
	return false;
}

void add_socket_ignore(unsigned short _ident){

	struct SOCKET_IGNORE * socket = ignore_management.start;

	for(int i = 0; i < ignore_management.nr; i++){
		if(socket->ident == _ident)
			return;

		socket = socket->next;
	}

	socket = malloc(sizeof(struct SOCKET_IGNORE));

	socket->ident = _ident;
	socket->offset = 0;
	socket->terminate = 0;

	if( ignore_management.nr++ == 0){
		ignore_management.start		= socket;
		socket->next				= socket;
		socket->prev				= socket;
	}
	else{
		socket->next = ignore_management.start;
		socket->prev = ignore_management.start->prev;

		ignore_management.start->prev->next = socket;
		ignore_management.start->prev = socket;
	}
}


void remove_socket_ignore(unsigned short _ident){


	struct SOCKET_IGNORE * socket = ignore_management.start;

	for(int i = 0; i < ignore_management.nr; i++){
		if(socket->ident == _ident)
			goto remove;

		socket = socket->next;
	}
	return;

	remove:

	if( ignore_management.nr == 1){
		ignore_management.nr = 0;
	}
	else
	{
		ignore_management.nr--;
		if(ignore_management.start == socket){
			ignore_management.start = socket->next;
		}
		socket->prev->next = socket->next;
		socket->next->prev = socket->prev;
	}
}


static void add_socket_node(struct UDP_SOCKET * socket){

	if( socket_ctrl.nr++ == 0){
		socket_ctrl.sockets			= socket;
		socket->next				= socket;
		socket->prev				= socket;
	}
	else{
		socket->next = socket_ctrl.sockets;
		socket->prev = socket_ctrl.sockets->prev;

		socket_ctrl.sockets->prev->next = socket;
		socket_ctrl.sockets->prev = socket;
	}
}


static void remove_socket_node(struct UDP_SOCKET * socket){


	if( socket_ctrl.nr == 1){
		socket_ctrl.nr = 0;
	}
	else
	{
		socket_ctrl.nr--;
		if(socket_ctrl.sockets == socket){
			socket_ctrl.sockets = socket->next;
		}
		socket->prev->next = socket->next;
		socket->next->prev = socket->prev;
	}
}




struct UDP_SOCKET * create_socket(unsigned char * ip_address, unsigned short srce_port, unsigned short dest_port){

	struct UDP_SOCKET * socket = socket_ctrl.sockets;

	for(int i =0; i < socket_ctrl.nr; i++){

		if((socket->srce_port == srce_port) && (socket->dest_port == dest_port)){
			return socket;
		}
		socket = socket->next;
	}

	socket = malloc(sizeof(struct UDP_SOCKET));
	socket->dest_port = dest_port;
	socket->srce_port = srce_port;

	memcpy(socket->dest_ip, ip_address, 4);
	socket->udp_socket = api_create_mailbox();

	add_socket_node(socket);
	return socket;
}

void delete_socket(struct UDP_SOCKET * socket){
	remove_socket_node(socket);
	free(socket);
}

void * udp_get_data_socket(struct UDP_SOCKET * socket, int timeout){
	return((void *)api_recieve_mail(socket->udp_socket, from_anyone, timeout));
}

bool socket_post(unsigned short dport, unsigned short sport, unsigned char * data){

	struct UDP_SOCKET * socket = socket_ctrl.sockets;

	for(int i =0; i < socket_ctrl.nr; i++){

		if((socket->srce_port == sport) && (socket->dest_port == dport)){
			api_post_to_mailbox(socket->udp_socket, to_anyone, data); return true;
		}
		socket = socket->next;
	}
	return false;
}


bool port_open(unsigned short dport, unsigned short sport, unsigned char * ip_srce){

	struct UDP_SOCKET * socket = socket_ctrl.sockets;

	for(int i =0; i < socket_ctrl.nr; i++){

		if((socket->srce_port == sport) && (socket->dest_port == dport) && (!memcmp(socket->dest_ip, ip_srce, 4))){
			return true;
		}
		socket = socket->next;
	}
	return false;
}


void send_udp_request(char * data, int data_length){


	struct ETHERNET_HEADER * ethernet_header = (struct ETHERNET_HEADER *)malloc(data_length + ETHERNET_HEADER_SIZE + IP_HEADER_SIZE + UDP_HEADER_SIZE);

	memcpy(ethernet_header->srce, mac_addr, 6);
	memcpy(ethernet_header->dest, t_mac_addr, 6);
	memcpy(ethernet_header->ptype, protocol_type_ip4, 2);



	struct IP_HEADER * ip_header = (struct IP_HEADER *)&ethernet_header->frame;
	memcpy(ip_header->vhl, vhl, 1);
	memcpy(ip_header->ip_service, ip_service, 1);

	unsigned short tmp_len = IP_HEADER_SIZE + UDP_HEADER_SIZE + data_length;
	ip_header->length[0] = tmp_len >> 8;
	ip_header->length[1] = tmp_len;

	memcpy(ip_header->ident, ident, 2);
	memcpy(ip_header->frags, frags, 2);

	memcpy(ip_header->ttl, ttl, 1);
	ip_header->pcol[0] = UDP;

	memcpy(ip_header->sip, ip_addr, 4);

	char test[4] = {62, 6, 40, 178};

	memcpy(ip_header->dip, test, 4);

	// set seq number
	ip_header->ident[0] = seqnum >> 8;
	ip_header->ident[1] = seqnum;
	if (++seqnum >= 0xFF00) seqnum = SEQ_NUM_START;


	// reset checksum before computation
	ip_header->check[0] = 0;
	ip_header->check[1] = 0;

	// compute IP checksum
	unsigned short chksum = in_cksum((unsigned short *)ip_header, IP_HEADER_SIZE);

	// set IP checksum
	ip_header->check[0] = chksum >> 8;
	ip_header->check[1] = chksum;



	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;
	udp_header->sport[0] = 0;
	udp_header->sport[1] = 25;

	udp_header->dport[0] = 0;
	udp_header->dport[1] = 53;

	unsigned short t_length = UDP_HEADER_SIZE + data_length;
	udp_header->length[0] = t_length >> 8;
	udp_header->length[1] = t_length;

	unsigned char * ptr = &udp_header->data;

	for(int i = 0; i < data_length;  i++){
		*ptr = *data; ptr++; data++;
	}

	struct PSEUDO_HEADER * pseudo_header = malloc(sizeof(struct PSEUDO_HEADER));
	memcpy(pseudo_header->scre, ip_addr, 4);
	memcpy(pseudo_header->dest, t_ip_addr, 4);

	pseudo_header->zero[0] = 0;
	pseudo_header->pcol[0] = UDP;

	unsigned short p_length = UDP_HEADER_SIZE + data_length;
	pseudo_header->udp_length[0] = p_length >> 8;
	pseudo_header->udp_length[1] = p_length;

	unsigned short pseudo_chksum = in_cksum((unsigned short *)pseudo_header, 12);
	pseudo_chksum = ~pseudo_chksum;

	udp_header->check[0] = pseudo_chksum >> 8;
	udp_header->check[1] = pseudo_chksum;

	free(pseudo_header);

	unsigned short udp_chksum = in_cksum((unsigned short *)&ip_header->data, UDP_HEADER_SIZE + data_length);

	udp_header->check[0] = udp_chksum >> 8;
	udp_header->check[1] = udp_chksum;


	ip_layer(ethernet_header);
	free(ethernet_header);
}

unsigned short udp_checksum(struct IP_HEADER * ip_header, int _length){

	struct UDP_HEADER * udp_header = (struct UDP_HEADER *)&ip_header->data;

	struct PSEUDO_HEADER * pseudo_header = malloc(sizeof(struct PSEUDO_HEADER));
	memcpy(pseudo_header->scre, ip_addr, 4);
	memcpy(pseudo_header->dest, t_ip_addr, 4);

	pseudo_header->zero[0] = 0;
	pseudo_header->pcol[0] = UDP;

	unsigned short p_length = UDP_HEADER_SIZE + _length;
	pseudo_header->udp_length[0] = p_length >> 8;
	pseudo_header->udp_length[1] = p_length;

	unsigned short pseudo_chksum = in_cksum((unsigned short *)pseudo_header, 12);
	pseudo_chksum = ~pseudo_chksum;

	udp_header->check[0] = pseudo_chksum >> 8;
	udp_header->check[1] = pseudo_chksum;

	free(pseudo_header);
	return(in_cksum((unsigned short *)&ip_header->data, UDP_HEADER_SIZE + _length));
}




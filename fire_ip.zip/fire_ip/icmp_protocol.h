/*
 * icmp_protocol.h
 *
 *  Created on: 14 Oct 2018
 *      Author: wmjen
 */

#ifndef ETHERNET_ICMP_PROTOCOL_H_
#define ETHERNET_ICMP_PROTOCOL_H_


#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ethernet_headers.h"
#include "D:\atmel-software-package-master\examples\getting_started\fire_ip\ip_layer\ip_protocol.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"


#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>



struct ICMP_IDENT{
	unsigned char

		* status,

		icmp_sequence[2],
		check_sum[2],

		source_mac[6],
		source_ip[4];

		unsigned long long timeout;

		struct ICMP_IDENT * next;
		struct ICMP_IDENT * prev;
};

struct ICMP_MANGER{
	struct ICMP_IDENT * ip_first_ping_request;
	int nr;
} icmp_manager;



extern void respond_to_ping(struct ETHERNET_HEADER *);
extern void _handle_ping_response(struct IP_HEADER *);

extern void icmp_timeout(void);

extern void add_icmp_node(struct ICMP_IDENT * );
extern void remove_icmp_node(struct ICMP_IDENT * );


extern void send_ping_response(struct ETHERNET_HEADER * ethernet_header, int);
extern void send_ping_request(unsigned char *, int, unsigned char [4]);


extern void log_ping_request(struct ICMP_HEADER *, unsigned char *);

#endif /* ETHERNET_ICMP_PROTOCOL_H_ */

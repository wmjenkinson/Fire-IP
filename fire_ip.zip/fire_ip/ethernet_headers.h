/*
 * ethernet_headers.h
 *
 *  Created on: 19 Oct 2018
 *      Author: wmjen
 */

#ifndef FIRE_IP_ETHERNET_HEADERS_H_
#define FIRE_IP_ETHERNET_HEADERS_H_



#define MACLEN	6	/* Ethernet (MAC) Address length */

/* Ethernet hardware Rx frame length includes the trailing CRC */
#define MAXFRAMEC	1518
#define MINFRAMEC	64

/* Higher-level drivers exclude the CRC from the frame length */
#define MAXFRAME	1514
#define MINFRAME	60

/*! initial sequence number for ICMP request and reply */
#define SEQ_NUM_START 0xf0

/*! sequence number for ICMP request and reply */
unsigned short seqnum;

/*! buffer for sending packets */
unsigned char mac_addr[6];

unsigned char ip_addr[4];
unsigned char t_ip_addr[4];
unsigned char gateway_addr[4];
unsigned char dns_addr[4];

unsigned char t_mac_addr[6];


unsigned char protocol_type_arp[2];
unsigned char protocol_type_ip4[2];
unsigned char ether_broacast[6];
unsigned char arp_broacast[6];

unsigned char hdr_ethernet[2];
unsigned char ethernet_length[1];
unsigned char ip_length[1];

unsigned char arp_request[2];
unsigned char arp_response[2];

/* Ethernet Header */
struct ETHERNET_HEADER{
	unsigned char

		 dest[MACLEN],		/* Destination MAC Address */
		 srce[MACLEN],		/* Source MAC Address */
		 ptype[2],

		 frame;
};

/* Ethernet frame; data size is frame size minus header & CRC */
#define ETHERMTU (MAXFRAME - sizeof(ETHERHDR))

/****** ARP (Address Resolution Protocol) packet ******/
struct ARP_HEADER{
	unsigned char

		hdr[2],				/* Hardware type					*/
	    pro[2],				/* protocol type					*/

		hin[1],				/* Length of Hardware address (6)	*/
	    pin[1],				/* Length of IP address (4)			*/

		op[2],				/* ARP opcode						*/

		smac[MACLEN],		/* Source MAC (Ethernet) address	*/
		sip[4],				/* Source IP address				*/

		dmac[MACLEN],		/* Destination MAC address			*/
		dip[4];				/* Destination IP address			*/

	};

#define HTYPE	0x0001		/* Hardware type: Ethernet		*/
#define ARPPRO  0x0800		/* Protocol type: IP			*/

#define ARPXXX	0x0000		/* ARP opcodes: unknown opcode	*/
#define ARPREQ  0X0001      /*				ARP request		*/
#define ARPRESP 0X0002      /*					response    */


struct IP_HEADER{
	unsigned char
		vhl[1],
		ip_service[1],

		length[2],
		ident[2],
		frags[2],

		ttl[1],
		pcol[1],

		check[2],

		sip[4],
		dip[4],

		data;
};

unsigned char vhl[1];
unsigned char ip_service[1];

unsigned char length[2];
unsigned char ident[2];
unsigned char frags[2];

unsigned char ttl[1];
unsigned char pcol[1];


#define ICMP	1	// Protocol Type:	ICMP
#define TCP		6	//					TCP
#define UDP		17	//					UDP

struct ICMP_HEADER{
	unsigned char
		type[1],	// Message Type
		code[1],	// Message Code

		check[2],	// Checksum
		indent[2],	// Identifier, possible unused
		seq[2],		// sequence number, possible unused
		data;
};

unsigned char type[1];      // Ping Request
unsigned char icmp_code[1]; // Ping Request

unsigned char indent[2];          // Ping Request



#define ICMP_REQ			8	// Message type echo request
#define ICMP_REP			0	//				echo reply
#define ICMP_UNREACH		3	//				destination unreachable

#define UNREACH_NET		0	// Destination Unreachable codes:	Network
#define UNREACH_HOST	1	//									host

#define UNREACH_PORT	3	//									port
#define UNREACH_FRAG	4	// Fragmentation needed, but disable flag set

struct UDP_HEADER{

	unsigned char
		sport[2],
		dport[2],
		length[2],
		check[2],

		data;
};

struct PSEUDO_HEADER{

	unsigned char

		scre[4],
		dest[4],

		zero[1],
		pcol[1],

		udp_length[2];
};

#define ETHERNET_HEADER_SIZE 14
#define IP_HEADER_SIZE 20
#define TCP_HEADER_SIZE 20
#define UDP_HEADER_SIZE 8
#define ICMP_HEADER_SIZE 8
#define PSEUDO_HEADER_SIZE 8

unsigned int tcp_test;

struct TCP_HEADER{

	unsigned short srce_port,
				   dest_port;

	unsigned char seq[4],
				  ack_[4];

	unsigned char header,
				  flags;

	unsigned short window,
				   checksum,
				   urgent;
};

#define FIN		0x01
#define SYN		0x02
#define RST		0x04
#define PUSH	0x08
#define ACK		0x10
#define URGE	0x20

struct TCP_PSEUDO{

	unsigned char srce_ip[4],
				  dest_ip[4];

	unsigned char zero,
				  pcol;

	unsigned short tcp_length;
};


#endif /* FIRE_IP_ETHERNET_HEADERS_H_ */
